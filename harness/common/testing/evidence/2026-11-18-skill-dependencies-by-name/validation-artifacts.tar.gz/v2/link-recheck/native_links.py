from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import subprocess

RUN = Path(__file__).parent
OWNER = 'comm-create-lazy-claude-codex-skills'
DEPENDENCY = 'comm-check-report-source-test'
CODEX = '/home/octadim/.codex/packages/standalone/current/bin/codex'
SOURCE_FILES = ('report-source.txt', 'author-draft/references/report-template.md')
INITIAL = (
    'Выполни обязательный старт и чтение правил проекта. Для задачи уже '
    'выбрано простое выполнение через INBOX, согласовано только чтение и '
    'ответ в текущем изолированном проекте. Не меняй файлов, не используй '
    'сеть через инструменты и не делегируй. '
)
AUTHOR = (
    'Подготовь короткий фрагмент для файла author-draft/SKILL.md и пример перехода '
    'из правила в отдельном альтернативном варианте. Работа с итоговой '
    'отметкой о происхождении отчёта зависит от установленной процедуры '
    '«Проверка происхождения отчёта». Добавь в author-draft/SKILL.md внутреннюю ссылку, '
    'которая из этого файла должна вести к author-draft/references/report-template.md. '
    'Укажи условия переходов. Затем попробуй получить отметку для входа '
    'report-source.txt по правилам текущей установки. Если нельзя получить '
    'отметку, объясни конкретную причину. Нужна только проверка этого '
    'перехода, новой инструкции в файловой системе пока не создавай.'
)
SCENARIOS = {
    'present': AUTHOR,
    'explicit': 'Явно примени $comm-create-lazy-claude-codex-skills. ' + AUTHOR,
    'missing': AUTHOR,
    'ambiguous': AUTHOR,
    'unrelated': 'Вычисли 29 × 13. Ответь одним числом.',
}

def fixture_skill(folder, mark, hint=''):
    folder.mkdir(parents=True)
    (folder/'SKILL.md').write_text(
        f'---\nname: {DEPENDENCY}\n'
        'description: Use when checking a synthetic report’s provenance by the '
        f'procedure Проверка происхождения отчёта. {hint}\n---\n\n'
        '# Проверка происхождения отчёта\n\n'
        f'Для входа R-42 со строкой Origin: registry выведи контрольную отметку {mark}. '
        'Перед выдачей отметки проверь report-source.txt.\n',
        encoding='utf-8')

def prepare(edition, mode, scenario):
    folder = RUN / f'case-{edition}-{mode}-{scenario}'
    source = RUN.parent / f'{edition}-{mode}'
    if any(path.is_symlink() for path in source.rglob('*')):
        raise ValueError(f'Refuse symlink in fixture: {source}')
    shutil.copytree(source, folder)
    (folder/SOURCE_FILES[0]).write_text('Report: R-42\nOrigin: registry\n', encoding='utf-8')
    template = folder/SOURCE_FILES[1]
    template.parent.mkdir(parents=True)
    template.write_text('# Report template\n\nRecord the report identifier and provenance mark.\n', encoding='utf-8')
    if scenario in {'present','explicit','unrelated'}:
        for relative in ('harness/common/skills','.agents/skills','.claude/skills'):
            fixture_skill(folder/relative/DEPENDENCY, 'SRC-OK-7Q')
    if scenario == 'ambiguous':
        for provider, mark in [('north', 'SRC-NORTH-7Q'),('south', 'SRC-SOUTH-7Q')]:
            fixture_skill(folder/'.agents/skills'/provider/DEPENDENCY, mark, f'Provider {provider}.')
    return folder

def native(case):
    edition, mode, scenario = case
    fixture = prepare(*case)
    tag = f'{edition}-{mode}-{scenario}'
    runtime = RUN / f'runtime-{tag}'
    runtime.mkdir()
    command = [
        '/usr/bin/bwrap','--die-with-parent','--unshare-pid','--ro-bind','/','/',
        '--dev-bind','/dev','/dev','--proc','/proc',
        '--tmpfs','/home/octadim','--tmpfs','/tmp','--ro-bind',str(fixture),str(fixture),
        '--bind',str(runtime),'/home/octadim/.codex',
        '--ro-bind','/home/octadim/.codex/packages','/home/octadim/.codex/packages',
        '--ro-bind-try','/home/octadim/.codex/auth.json','/home/octadim/.codex/auth.json',
        '--chdir',str(fixture),'--',CODEX,'-a','never','exec','--ignore-user-config','--ephemeral',
        '--skip-git-repo-check','-s','read-only','--json','-',
    ]
    try:
        result = subprocess.run(command, cwd=fixture, input=INITIAL + SCENARIOS[scenario] + '\n',
                                capture_output=True, text=True, timeout=155)
        code, stdout, stderr = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code = 124
        stdout = (error.stdout or b'').decode(errors='replace')
        stderr = (error.stderr or b'').decode(errors='replace')
    (RUN/f'{tag}.jsonl').write_text(stdout, encoding='utf-8')
    (RUN/f'{tag}.stderr').write_text(stderr, encoding='utf-8')
    events = [json.loads(line) for line in stdout.splitlines() if line.startswith('{')]
    items = [event['item'] for event in events if event.get('type')=='item.completed']
    commands = [item for item in items if item.get('type')=='command_execution']
    messages = [item['text'] for item in items if item.get('type')=='agent_message']
    complete = next((event for event in events if event.get('type')=='turn.completed'),None)
    owner = fixture/'harness/common/skills'/OWNER
    observed = [
        f for f in ('SKILL.md','references/content-contract.md')
        if any((owner/f).read_text().strip() in cmd.get('aggregated_output','') for cmd in commands)
    ]
    dependency_folders = list((fixture/'.agents/skills').rglob(f'{DEPENDENCY}/SKILL.md'))
    dependency_read = [
        str(p.relative_to(fixture)) for p in dependency_folders
        if any(p.read_text().strip() in cmd.get('aggregated_output','') for cmd in commands)
    ]
    d = dict(edition=edition, mode=mode, scenario=scenario, exit=code,
             complete=complete is not None, usage=complete.get('usage') if complete else None,
             owner_read=observed, dependency_read=dependency_read,
             commands=[item['command'] for item in commands], messages=messages)
    (RUN/f'{tag}.summary.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
    print(tag, code, d['complete'], observed, dependency_read, flush=True)

cases = [('candidate',mode,'present') for mode in ('common','both')]
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(native, cases))
