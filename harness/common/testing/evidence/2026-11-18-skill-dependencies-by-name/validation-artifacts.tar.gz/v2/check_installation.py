from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd()
RUN = Path(__file__).parent
OWNER = 'comm-create-lazy-claude-codex-skills'
CANDIDATE = ROOT / 'harness/common/inbox/2026-11-18-skill-dependencies-by-name/candidate-v2' / OWNER
PYTEST = '/tmp/harness-full-routes.sX93GCkU/venv/bin/python'

def ordinary(path):
    for component in (*reversed(path.parents), path):
        if component.is_symlink():
            raise ValueError(f'Symlink: {component}')

def copy_tree(source, target, exclude_history=False):
    ordinary(source)
    if source.is_dir():
        target.mkdir(parents=True, exist_ok=True)
        for item in sorted(source.iterdir()):
            if item.name in {'__pycache__', '.pytest_cache'}:
                continue
            if exclude_history and item.name in {'inbox', 'evidence', 'handoffs'}:
                (target / item.name).mkdir(exist_ok=True)
                continue
            copy_tree(item, target / item.name, exclude_history)
    elif source.name == 'README.human.md':
        target.write_text('# Human-only fixture guide\n\nExample: adjacent project material.\n')
    elif source.is_file():
        shutil.copyfile(source, target)
    else:
        raise ValueError(f'Not an ordinary file: {source}')

def manifest(folder):
    return {
        str(path.relative_to(folder)): None if path.is_dir() else sha256(path.read_bytes()).hexdigest()
        for path in sorted(folder.rglob('*')) if path.name != 'README.human.md'
    }

def run(root, *command):
    result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=60)
    return dict(command=command, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)

def write_entrypoints(root):
    (root / 'AGENTS.md').write_text(
        '# Harness\n\nRun this from the current project first, stopping on error.\n\n'
        '```sh\npython3 -B harness/common/checks/ensure_entrypoint_links.py\n```\n\n'
        'Read in this order. Work within this synthetic project.\n\n'
        '- [harness/common/START.md](harness/common/START.md)\n'
        '- [harness/project/START.md](harness/project/START.md)\n'
        '- [.claude/rules](.claude/rules/) Read all Markdown rules recursively before the task, except README.human.md.\n'
        '- [harness/common/INDEX.md](harness/common/INDEX.md)\n'
        '- [harness/project/INDEX.md](harness/project/INDEX.md)\n',
        encoding='utf-8',
    )
    (root / 'CLAUDE.md').write_text('@AGENTS.md\n', encoding='utf-8')

def fixture(version, mode):
    root = RUN / f'{version}-{mode}'
    root.mkdir()
    common = root / 'harness/common'
    project = root / 'harness/project'
    copy_tree(ROOT / 'harness/common', common, exclude_history=True)
    if version == 'candidate':
        copy_tree(CANDIDATE, common / 'skills' / OWNER)
        # Human guides are fixture-only, including the two copies of the same skill.
    if mode == 'both':
        copy_tree(ROOT / 'harness/project', project, exclude_history=True)
        (project / 'decisions/fixture.md').write_text('Existing project fixture.\n')
        prior = manifest(project)
    else:
        assert not project.exists()
    write_entrypoints(root)
    copy_tree(common / 'rules', root / '.claude/rules')
    for native in ('.agents', '.claude'):
        copy_tree(common / 'skills', root / native / 'skills')
    initial = run(root, 'python3', '-B', 'harness/common/checks/ensure_entrypoint_links.py')
    assert initial['exit'] == 0, initial
    initialized = manifest(root)
    repeat = run(root, 'python3', '-B', 'harness/common/checks/ensure_entrypoint_links.py')
    assert repeat['exit'] == 0 and manifest(root) == initialized, repeat
    if mode == 'common':
        assert (project / 'testing/evidence/work').is_dir()
        assert (project / 'testing/evidence/harness').is_dir()
        assert not [path for path in (project / 'inbox').iterdir() if path.name != 'README.human.md']
    else:
        assert manifest(project) == prior
    active = common / 'skills' / OWNER
    for native in ('.agents', '.claude'):
        assert manifest(root / native / 'skills' / OWNER) == manifest(active)
    checks = run(root, PYTEST, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                 'harness/common/testing/tests/test_rule_copies.py',
                 'harness/common/testing/tests/test_skills_first_knowledge.py')
    assert checks['exit'] == 0, checks
    result = dict(version=version, mode=mode, initial=initial, repeat=repeat,
                  repeat_invariant=True, project_preserved=mode == 'both',
                  neutral_project=mode == 'common', native_copy_equality=True,
                  target_manifest=manifest(active), checks=checks)
    (RUN / f'{version}-{mode}-structure.json').write_text(json.dumps(result, indent=2) + '\n')
    print(version, mode, checks['stdout'].strip().splitlines()[-1], flush=True)

for version in ('base', 'candidate'):
    for mode in ('common', 'both'):
        fixture(version, mode)
