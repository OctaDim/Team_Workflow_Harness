from pathlib import Path
import hashlib, shutil, subprocess, json
work=Path(__file__).parent
root=Path.cwd()
owner='comm-retry-external-operations'
candidate=root/'harness/common/inbox/2026-11-19-01-external-operation-retries/comm-retry-external-operations'
def manifest(p):
 return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
def copy(p,q):
 shutil.copytree(p,q,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for stage in ('candidate',):
 for mode in ('common','combined'):
  p=work/f'{stage}-{mode}'
  p.mkdir()
  subprocess.run(['git','init','-q',str(p)],check=True)
  for f in ('AGENTS.md','CLAUDE.md'): shutil.copyfile(root/f,p/f)
  c=p/'harness/common'
  c.mkdir(parents=True)
  for f in ('START.md','INDEX.md'): shutil.copyfile(root/'harness/common'/f,c/f)
  for f in ('base','checks','rules','skills'): copy(root/'harness/common'/f,c/f)
  copy(candidate,c/'skills'/owner)
  copy(c/'rules',p/'.claude/rules')
  copy(c/'skills',p/'.agents/skills')
  if mode=='combined':
   copy(root/'harness/project',p/'harness/project')
   (p/'harness/project/decisions/existing.md').write_text('Synthetic existing project record.\n')
   before=manifest(p/'harness/project')
  (p/'inputs.csv').write_text('quantity,unit_value\n23,8\n')
  for i in range(2):
   subprocess.run(['python3','-B','harness/common/checks/ensure_entrypoint_links.py'],cwd=p,check=True,stdout=subprocess.DEVNULL)
   after=manifest(p/'harness/project')
   if i or mode=='combined': assert before==after
   before=after
  print(stage,mode,'startup OK')