from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess
w=Path(__file__).parent;home=Path.home()/'.codex'
prompts=json.loads((w/'prompts.json').read_text())
def run(spec):
 mode,case=spec;tag=mode+'-'+case
 r=w/(tag+'-fixture' if case in ('linked','history') else 'candidate-'+mode)
 profile=w/(tag+'-profile');profile.mkdir()
 cmd=['bwrap','--die-with-parent','--ro-bind','/','/','--tmpfs','/home','--tmpfs','/tmp','--tmpfs','/mnt','--ro-bind','/mnt/wsl/resolv.conf','/mnt/wsl/resolv.conf','--dev','/dev','--proc','/proc','--bind',str(profile),str(home),'--ro-bind',str(home/'auth.json'),str(home/'auth.json'),'--ro-bind',str(home/'packages'),str(home/'packages'),'--ro-bind',str(r),str(r),'--chdir',str(r)]
 extra=[]
 if case in ('actions','timer'):
  file=w/('schema.json' if case=='actions' else 'timer-schema.json')
  cmd+=['--ro-bind',str(file),'/tmp/response-schema.json'];extra=['--output-schema','/tmp/response-schema.json']
 cmd+=['--',str(home/'packages/standalone/current/bin/codex'),'-a','never','exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','-C',str(r),'-s','read-only','-m','gpt-6.2-sol','-c','features.multi_agent=false','-c','model_reasoning_effort="medium"','--json',*extra,prompts[case]]
 with (w/(tag+'.jsonl')).open('xb') as out,(w/(tag+'.stderr')).open('xb') as err:
  try:rc=subprocess.run(cmd,cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=420).returncode
  except subprocess.TimeoutExpired:rc=124
 print(tag,rc,flush=True)
 return rc
if __name__=='__main__':
 jobs=[(m,c) for c in ('short','explicit','implicit','csv','actions','timer','linked','history') for m in ('common','combined')]
 with ThreadPoolExecutor(max_workers=6) as pool:
  results=list(pool.map(run,jobs))
 (w/'exit.json').write_text(json.dumps(dict(zip(('-'.join(j) for j in jobs),results))))
