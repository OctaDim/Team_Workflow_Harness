from pathlib import Path
import json,re,sys
from analyse import lib,measure,sha,w
def items(mode,case):
 p=w/(mode+'-'+case+'.jsonl'); events=[json.loads(l) for l in p.open() if l.endswith('\n')]
 starts={e['item']['id']:n for n,e in enumerate(events) if e['type']=='item.started'}
 tools=[dict(e['item'],start_event=starts[e['item']['id']],end_event=n) for n,e in enumerate(events) if e['type']=='item.completed' and e['item']['type']=='command_execution']
 return events,tools
def inspect(mode,case):
 events,tools=items(mode,case)
 if not events or events[-1]['type']!='turn.completed': return None
 msgs=[e['item']['text'] for e in events if e['type']=='item.completed' and e['item']['type']=='agent_message']
 answer=msgs[-1] if msgs else ''
 if case in ('linked','history'):
  r=w/(mode+'-'+case+'-fixture');exp,starts,aliases=lib['snapshot_rule_inputs'](r)
  config='.agents/skills/config-check/SKILL.md';skill='.agents/skills/example/SKILL.md'
  links={'.claude/rules/'+n:{config:0} for n in ('request-kind.md','remaining.md')} if case=='linked' else {}
  bodies={t:(r/t).read_text() for t in (skill,config)}
  a=lib['assess_rule_reading'](tools,exp,starts=starts,aliases=aliases,root=r,immutable_fixture=True,skill_links=links,task_skills={skill},skill_bodies=bodies)
  human_hit=any('HUMAN_BODY_CANARY_' in t.get('aggregated_output','') for t in tools)
  bh=[t['end_event'] for t in tools if bodies[config] in t['aggregated_output']]
  correct=bool(re.search(r'\b56\b',answer)) and (len(bh)==1 if case=='linked' else not bh) and not human_hit
  d=dict(mode=mode,scenario=case,report=a['rule_read_report'].copy(),checked=a['rule_reading_pass'] and correct,app=correct,answer=answer,config_hits=bh,trace_sha256=sha((w/(mode+'-'+case+'.jsonl')).read_bytes()))
  if not correct:d['report'][-1]+='; не подтверждён ожидаемый прикладной результат или условное чтение'
 else:
  d=measure(mode,case)
 d['commands']=[{'from':t['start_event']+1,'to':t['end_event']+1,'command':t['command'],'exit':t['exit_code'],'output_sha256':sha(t['aggregated_output'].encode())} for t in tools]
 return d
if __name__=='__main__':
 for p in sorted(w.glob('*.jsonl')):
  m,c=p.stem.split('-',1)
  try:r=inspect(m,c)
  except Exception as exc:print(m,c,'unable to audit',type(exc).__name__,str(exc)[:150]);continue
  if r:print(m,c,r['checked'],r['report'][-1])
