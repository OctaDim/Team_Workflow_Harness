from pathlib import Path
import json,runpy,hashlib,sys
w=Path(__file__).parent
lib=runpy.run_path('harness/common/checks/check_human_guide_search.py')
sha=lambda data:hashlib.sha256(data).hexdigest()
def measure(mode,case):
 f=w/(mode+'-'+case+'.jsonl')
 if case in ('linked','history'):
  r=json.loads(f.with_suffix('.json').read_text())
  return {'scenario':case,'mode':mode,'checked':r['pass'],'report':r['rule_read_report'],'duplicates':r['duplicate_rule_reads'],'skill_duplicates':r['duplicate_skill_reads'],'sha256':sha(Path(r['raw_events_path']).read_bytes()),'complete':r['native_completed']}
 root=w/('candidate-'+mode); events=[json.loads(x) for x in f.read_text().splitlines()]
 starts_at={e['item']['id']:n for n,e in enumerate(events) if e['type']=='item.started'}
 tools=[dict(e['item'],start_event=starts_at[e['item']['id']],end_event=n) for n,e in enumerate(events) if e['type']=='item.completed' and e.get('item',{}).get('type')=='command_execution']
 expected,starts,aliases=lib['snapshot_rule_inputs'](root)
 skills={str(p.relative_to(root)):p.read_text() for p in (root/'harness/common/skills').glob('*/SKILL.md')}
 target='harness/common/skills/comm-retry-external-operations/SKILL.md'
 workflow='harness/common/skills/comm-select-development-workflow/SKILL.md'
 paths=lib['installed_skill_aliases'](root,skills)
 tokens=lambda t:[a.removeprefix(str(root)+'/').removeprefix('./') for a in lib['command_tokens'](t['command'])]
 body_hits=lambda body:[(t['start_event'],t['end_event']) for t in tools if body.strip() in t['aggregated_output']]
 work_body=body_hits(skills[workflow])
 owner='.claude/rules/comm-confirm-development-workflow.md'
 # The route is considered only when the agent actually starts evaluating it.
 links={owner:{workflow:work_body[0][0]}} if work_body else {}
 args=dict(starts=starts,aliases=aliases,root=root,immutable_fixture=True,skill_links=links,skill_bodies=skills,
           task_skills={target} if case!='csv' else set(),search_at=len(tools) if case=='csv' else None)
 a=lib['assess_rule_reading'](tools,expected,**args)
 # The generic auditor recognizes SKILL.md bodies. Verify direct referenced resources separately.
 checked=[]; extra=[]
 for t in tools:
  tks=tokens(t)
  if tks[:1]==['cat'] and len(tks)==2 and '/references/' in tks[1]:
   res=root/tks[1]
   if res.is_file() and work_body and t['start_event']>work_body[0][1] and 'comm-select-development-workflow' in res.parts and res.name in skills[workflow] and t['aggregated_output']==res.read_text():
    extra.append(tks[1]);checked.append(dict(t,command='true',aggregated_output=''));continue
  checked.append(t)
 b=lib['assess_rule_reading'](checked,expected,**args)
 hits=body_hits(skills[target]); initial=bool(tools and tokens(tools[0]) in (['python3','harness/common/checks/ensure_entrypoint_links.py'],['python3','-B','harness/common/checks/ensure_entrypoint_links.py']) and tools[0]['exit_code']==0)
 def combined_hits(doc):
  records=[]
  for pkg in ('common','project'):
   body=(root/f'harness/{pkg}/{doc}.md').read_text().strip()
   records.append(next(((t['start_event'],t['end_event'],t['aggregated_output'].find(body)) for t in tools if body in t['aggregated_output']),None))
  return records
 st,idx=combined_hits('START'),combined_hits('INDEX')
 goodstart=initial and all(st) and tools[0]['end_event']<st[0][0] and st[0]<=st[1]
 goodidx=all(idx) and idx[0]<=idx[1]
 proper=bool(goodidx and hits and hits[0][0]>idx[1][1])
 answers=[e['item']['text'] for e in events if e.get('item',{}).get('type')=='agent_message']; answer=answers[-1] if answers else ''
 human={p.read_bytes().strip() for p in root.rglob('README.human.md')}; exposed=any(body and body in t['aggregated_output'].encode() for body in human for t in tools)
 behavior=None
 if case=='actions':
  actions=json.loads(answer);replay=runpy.run_path(str(w/'replay.py'))['replay'];behavior={}
  for k in ('lost','stale','recover','slow','abort','bad','sdk','hint','allowed'):
   try:behavior[k]=replay(k,actions[k])
   except (AssertionError,KeyError):behavior[k]=False
 if case=='timer':behavior=json.loads(answer)
 if case=='csv':behavior=answer.strip()=='184' and not hits
 reasons=[]
 if not goodstart:reasons.append('стартовая команда и полные START не подтверждены в порядке')
 if not goodidx:reasons.append('не подтверждены полные INDEX в порядке')
 if (case!='csv' and not proper) or (case=='csv' and hits):reasons.append('не подтверждено ожидаемое чтение или отсутствие тела целевого скилла')
 if exposed:reasons.append('тело human-материала в выводе')
 if events[-1]['type']!='turn.completed':reasons.append('сессия не завершена')
 if behavior is False or case=='actions' and not all(behavior.values()) or case=='timer' and behavior!={'attempt_timeout':2,'hint_delay':3,'new_sends_after_cancel':0}:reasons.append('не пройден прикладной сценарий')
 lines=b['rule_read_report'].copy()
 if reasons:lines[-1]=('Результат: Ошибка - ' if b['rule_reading_pass'] else lines[-1]+', ')+', '.join(reasons)
 return dict(mode=mode,scenario=case,checked=b['rule_reading_pass'] and not reasons,report=lines,raw_auditor=a['rule_read_report'][-1],verified_resources=extra,
   first_reads=b['first_reads'],duplicates=b['duplicate_rule_reads'],skill_duplicates=b['duplicate_skill_reads'],starts=st,indexes=idx,target_hits=hits,app=behavior,answer=answer,
   trace_sha256=sha(f.read_bytes()),command_count=len(tools),observed_output_bytes=sum(len(t['aggregated_output'].encode()) for t in tools),usage=events[-1].get('usage'))
if __name__=='__main__':
 for mode in ('common','combined'):
  for case in sys.argv[1:]:
   r=measure(mode,case);print(mode,case,r['checked'],r['report'][-1],r.get('verified_resources'))
