from pathlib import Path
import hashlib,json,re
from boundary import body,triplet,owner,w
rows=json.loads((w/'review.json').read_text())
assert len(rows)==30 and all(r['cli']['completed']=='turn.completed' for r in rows)
out=[]
for r in rows:
    tag=r['tag'];calls=r['dialogue'];case=r['cli']['case'];stage=tag.rsplit('-',1)[1]
    chk=[]
    for j,c in enumerate(calls):
        if c['body_returned']:chk.append({'triplet':triplet(calls,j),'read':c['call'],'delivered':c['result'],'exact':body in c['outputs']})
    index=[]
    for pkg in ('common','project'):
        expected=(w/('candidate-'+r['cli']['mode']+'-normal')/'harness'/pkg/'INDEX.md').read_text()
        index.append(next(((c['call'],c['result'],s.index(expected)) for c in calls for s in c['outputs'] if expected in s),None))
    target=owner+'/SKILL.md'
    obs={'tag':tag,'preloaded':len(r['preload']),'reads':chk,'indexes':index,'startup_auditor':r['cli']['rule_report']}
    if stage.startswith('plain'):
        assert not r['preload'] and len(chk)==1 and all(index) and index[0]<=index[1]
        triple=chk[0]['triplet']
        assert triple and body in next(c for c in calls if c['call']==triple[2])['outputs']
        if case=='reuse':
            link=next(i for i,c in enumerate(calls) if '.claude/rules/comm-training.md' in c['source'] and any(target in s for s in c['outputs']))
            obs['first_required_probe']=calls[link+1]['call']
            obs['first_probe_delivered']=calls[link+1]['result']
            obs['next_call']=calls[link+2]['call']
            late=[c['call'] for c in calls if c['call']>index[1][1] and target in c['source']]
            obs['target_after_indexes']=late
            ok=triple[0]==calls[link+1]['call'] and triple[2]==calls[link+2]['call'] and chk[0]['delivered']<index[0][0] and not late
        else:
            ok=index[1][1]<triple[0]
        obs['outcome']='pass' if ok else 'fail'
    elif r['preload']:
        assert stage in ('one','two') and len(r['preload'])==1 and r['preload'][0]['body_sha256']==hashlib.sha256(body.encode()).hexdigest()
        obs['outcome']='fail' if chk else 'pass'
    elif case in ('file-link','dir-link','ambiguous'):
        diagnostic='ermission denied' if case=='ambiguous' else 'символическая ссылка'
        probed=[c for c in calls if any('training/tool' in s and diagnostic in s for s in c['outputs']) and 'lstat' in c['source']]
        assert len(probed)==1 and not chk
        c=probed[0]
        assert not any('Observation marker D17-FILE-CONTENTS' in s for t in calls for s in t['outputs'])
        assert not any(any(op in t['source'] for op in ('read_text(', 'read_bytes(', 'open(', 'cat training','cat /fixture/training')) for t in calls if 'training/tool' in t['source'])
        obs['stop']=[c['call'],c['result']];obs['outcome']='pass'
    elif case=='csv':
        assert r['cli']['application'] and not chk;obs['outcome']='pass'
    else:
        assert len(chk)==1 and chk[0]['triplet'] and chk[0]['exact']
        if case in ('actions','timer'):assert r['cli']['application']
        obs['outcome']='pass'
    out.append(obs)
assert sum(r['outcome']=='pass' for r in out if '-plain' in r['tag'])==7
(w/'outcomes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
lines=['# Нативные прогоны Codex','', 'Три числа обозначают внешний вызов проверки пути, доставку его ответа и начало вызова чтения. Нумерация записей диалога с единицы. Шесть строк — дословный вывод штатного аудитора команд. Его ожидание открыть файл неприменимо при подстановке тела, а остановка на недопустимом пути может прервать старт до INDEX. Вердикт о целевом поведении берётся из диалога.','']
for r,o in zip(rows,out):
    lines.extend(['## '+o['tag'],'',*['- '+v for v in o['startup_auditor']],''])
    lines.append('Целевой сценарий — '+('пройден.' if o['outcome']=='pass' else 'не пройден.'))
    if o['preloaded']:lines.append('Полный актуальный текст находился в контексте до начала старта. Повторных выдач целевого текста — '+str(len(o['reads']))+'.')
    for read in o['reads']:
        if read['triplet']:lines.append('Последовательность '+ ' → '.join(map(str,read['triplet']))+'. Полный текст доставлен в записи '+str(read['delivered'])+'.')
        else:lines.append('Чтение в записи '+str(read['read'])+', выдача '+str(read['delivered'])+'. Раздельность не подтверждена.')
    if 'stop' in o:lines.append('Проверка и доставка отказа '+' → '.join(map(str,o['stop']))+'. Целевой файл не открыт.')
    if 'first_required_probe' in o and o['outcome']=='fail':lines.append('Первая обязательная проверка 83, доставка 86, следующий вызов 90 открывает другое правило. Пара 110 → 113 → 115 относится к позднему чтению после INDEX.')
    lines.append('')
(w/'run-reports.md').write_text('\n'.join(lines))
