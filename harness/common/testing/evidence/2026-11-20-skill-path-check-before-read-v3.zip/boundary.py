"""Check outer calls in this frozen set of traces; unsupported command forms require review."""
import ast,json,re,shlex
from pathlib import Path
w=Path(__file__).parent
owner='comm-retry-external-operations'
canonical=f'harness/common/skills/{owner}/SKILL.md'
body=(w/'candidate-common-normal'/canonical).read_text()
def command(source):
    # Only one literal shell command passed through an ordinary exec wrapper.
    match=re.fullmatch(r'\s*text\(\(?await tools\.exec_command\(\{\s*cmd\s*:\s*("(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|\x60(?:\\.|[^\x60\\])*\x60)(?:\s*,\s*(?:workdir|max_output_tokens|yield_time_ms)\s*:\s*(?:"/fixture"|\d+))*\s*\}\)\)?(?:\.output)?\)\s*;?\s*',source,re.S)
    if not match:return None
    literal=match[1]
    if literal[0]=='"':return json.loads(literal)
    if literal[0]=="'":return ast.literal_eval(literal)
    if '${' in literal:return None
    return literal[1:-1].replace('\\\x60','\x60').replace('\\\\','\\')
def read_path(call):
    cmd=command(call['source'])
    if cmd is None:return None
    args=shlex.split(cmd)
    if args[:1]==['cat'] and len(args)==2 and args[-1].endswith('/'+owner+'/SKILL.md'):
        return args[-1].removeprefix('/fixture/').removeprefix('./')
def confirmed(check,path):
    cmd=command(check['source'])
    if not cmd or path not in cmd or check.get('body_returned'):return False
    outputs='\n'.join(check['outputs'])
    if cmd.startswith('namei '):
        tokens=shlex.split(cmd)
        allowed={path,canonical,f'.agents/skills/{owner}/SKILL.md'}
        if not all(t in ('-l','--') or t.removeprefix('/fixture/') in allowed for t in tokens[1:]):return False
        for block in re.split(r'(?m)^f: ',outputs)[1:]:
            lines=block.strip().splitlines()
            if lines[0].removeprefix('/fixture/')!=path:continue
            parts=list(Path(lines[0]).parts)
            entries=lines[1:1+len(parts)]
            if [s.split()[-1] for s in entries]==parts and all(s.startswith('d') for s in entries[:-1]) and entries[-1].startswith('-'):return True
        return False
    # Metadata-only Python probes below are additionally inspected in the per-run dialogue.
    if not cmd.startswith('python3 ') or any(t in cmd for t in ('read_text','read_bytes','open(', 'rg ', '&&','subprocess','os.system','sha256')):return False
    whole=any(t in cmd for t in ('parents','components','split('))
    types=('lstat' in cmd and 'S_ISDIR' in cmd and 'S_ISREG' in cmd) or ('is_symlink' in cmd and 'is_file' in cmd)
    signal=(path in outputs or re.search(r'(?im)^(ok|safe|allowed|regular|путь допустим)\b',outputs))
    return bool(whole and types and signal and not re.search(r'permission denied|traceback',outputs,re.I))
def triplet(calls,j):
    if j<1:return None
    check,read=calls[j-1:j+1]
    path=read_path(read)
    if not (path and read.get('body_returned') and body in read['outputs'] and confirmed(check,path)):return None
    if not check['call']<check['result']<read['call']<read['result']:return None
    return [check['call'],check['result'],read['call']]
