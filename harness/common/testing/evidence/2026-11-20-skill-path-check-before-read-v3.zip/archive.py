from pathlib import Path
import hashlib,json,zipfile
w=Path(__file__).parent
root=Path('harness/common/testing/evidence')
v2=root/'2026-11-20-skill-path-check-before-read-v2.zip'
name='2026-11-20-skill-path-check-before-read-v3.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
files=['prepare.py','native-recorded.py','run-plain.py','run-extra.py','catalogue.py','controls.py','outer_controls.py','audit.py','details.py','review.py','replay.py','boundary.py','evaluate.py','archive.py','comm-instruction-order-v3.md','prompts.json','schema.json','timer-schema.json','fixtures.json','controls.json','outer-controls.json','catalogue.json','pytest.log','start.json','analyze.json','explain-budget.json','review.json','outcomes.json','run-reports.md']
contents={f:(w/f).read_bytes() for f in files}
with zipfile.ZipFile(v2) as z:
    rows=json.loads(z.read('review.json'))
    contents['v2/reference-controls.json']=json.dumps({r['tag']:r['dialogue'] for r in rows if r['tag'] in ('candidate-combined-explicit-plain1','candidate-combined-reuse-plain2','candidate-common-explicit-plain1','candidate-combined-explicit-plain2')},ensure_ascii=False).encode()
    contents['v2/verdicts.json']=z.read('verdicts.json')
for p in sorted(w.glob('candidate-*.jsonl')):
    contents['cli/'+p.name]=p.read_bytes()
    roll,=(w/(p.stem+'-profile')/'sessions').rglob('rollout*.jsonl')
    evidence=[]
    for n,line in enumerate(roll.open(),1):
        event=json.loads(line);d=event['payload']
        if event['type']=='response_item' and d.get('type') in ('custom_tool_call','custom_tool_call_output','function_call','function_call_output'):
            record={k:d[k] for k in ('type','call_id','name','input','arguments','output') if k in d}
            evidence.append(json.dumps(dict(line=n,**record),ensure_ascii=False))
    contents['dialogue/'+p.name]=('\n'.join(evidence)+'\n').encode()
contents['SHA256.json']=json.dumps({k:sha(v) for k,v in contents.items()},indent=2).encode()
with zipfile.ZipFile(w/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for k,b in contents.items():z.writestr(k,b)
with zipfile.ZipFile(w/name) as z:
    assert z.testzip() is None and all(sha(z.read(k))==h for k,h in json.loads(z.read('SHA256.json')).items())
with (root/name).open('xb') as f:f.write((w/name).read_bytes())
