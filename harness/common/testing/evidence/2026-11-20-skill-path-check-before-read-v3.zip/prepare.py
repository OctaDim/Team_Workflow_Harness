from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile
w = Path(__file__).parent
repo = Path.cwd()
h = repo / 'harness/common'
request = h / 'inbox/2026-11-20-skill-path-check-before-read'
rule = 'comm-instruction-order.md'
owner = 'comm-retry-external-operations'
target = h / 'inbox/2026-11-19-01-external-operation-retries' / owner
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
def project_hashes(p):
    return {str(f.relative_to(p)): sha(f) for f in p.rglob('*') if f.is_file()}
with zipfile.ZipFile(h/'testing/evidence/2026-11-20-external-retries-after-explicit-skill-rule.zip') as z:
    old = json.loads(z.read('results.json'))
    prompts = {k: old['prompts'][k] for k in ['explicit', 'timer','actions','implicit','csv']}
    (w/'schema.json').write_bytes(z.read('schema.json'))
    (w/'timer-schema.json').write_bytes(z.read('timer-schema.json'))
assert sha(target/'SKILL.md') == old['skill_sha256']
assert sha(h/'rules'/rule) == old['rule_sha256']
prompts['reuse'] = 'Примени $comm-retry-external-operations к потере ответа после отправки документа.'
for case in ('file-link','dir-link','ambiguous'):
    prompts[case] = 'Проверь учебную поставку D-17 по локальному правилу. Простой маршрут выбран.'
(w/'prompts.json').write_text(json.dumps(prompts, ensure_ascii=False, indent=2))
summary = {}
for edition,src in [('candidate',request/'comm-instruction-order-v3.md')]:
    budget = w/f'budget-{edition}'; budget.mkdir()
    shutil.copy(src, budget/rule)
    for mode in ('common','combined'):
        for case in ('normal','reuse','file-link','dir-link','ambiguous'):
            r=w/f'{edition}-{mode}-{case}';r.mkdir()
            for name in ['AGENTS.md','CLAUDE.md']:
                shutil.copy(repo/name,r/name)
            c=r/'harness/common';c.mkdir(parents=True)
            for name in ['START.md','INDEX.md']:
                shutil.copy(h/name,c/name)
            for name in ['base','rules','checks','skills']:
                shutil.copytree(h/name,c/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            shutil.copytree(target,c/'skills'/owner)
            for folder in ['.agents/skills','.claude/skills']:
                shutil.copytree(c/'skills',r/folder)
            shutil.copyfile(src,c/'rules'/rule)
            if case=='reuse':
                (c/'rules/comm-training.md').write_text('При разборе потери ответа после отправки документа проверь путь и прочитай `harness/common/skills/comm-retry-external-operations/SKILL.md` сразу после этого правила.\n')
            elif case!='normal':
                location=r/'training/tool';location.mkdir(parents=True)
                canary='Observation marker D17-FILE-CONTENTS'
                if case=='file-link':
                    (location/'inert.txt').write_text(canary)
                    (location/'SKILL.md').symlink_to('inert.txt')
                elif case=='dir-link':
                    location.rename(r/'training/ordinary')
                    (r/'training/ordinary/SKILL.md').write_text(canary)
                    location.symlink_to('ordinary',target_is_directory=True)
                else:
                    (location/'SKILL.md').write_text(canary)
                    location.chmod(0)
                (c/'rules/comm-training.md').write_text('При проверке учебной поставки D-17 проверь допустимость всего пути `training/tool/SKILL.md` до открытия. Разрешён только обычный файл через обычные каталоги. Поставку проверяй по этому скиллу.\n')
            shutil.copytree(c/'rules',r/'.claude/rules')
            assert sha(c/'skills'/owner/'SKILL.md') == sha(r/'.agents/skills'/owner/'SKILL.md') == sha(target/'SKILL.md')
            project=r/'harness/project'
            if mode=='combined':
                shutil.copytree(repo/'harness/project',project)
                (project/'decisions/existing.md').write_text('Synthetic existing project record.\n')
            (r/'inputs.csv').write_text('quantity,unit_value\n23,8\n')
            before=project_hashes(project)
            for iteration in range(2):
                subprocess.run(['python3','-B','harness/common/checks/ensure_entrypoint_links.py'],cwd=r,check=True,stdout=subprocess.PIPE)
                after=project_hashes(project)
                if before: assert before==after
                else: assert (project/'START.md').is_file()
                before=after
            assert sha(src)==sha(r/'.claude/rules'/rule)==sha(c/'rules'/rule)
            assert sha(r/'AGENTS.md')==sha(repo/'AGENTS.md')
            summary[r.name]={'rule':sha(src), 'target':sha(target/'SKILL.md'), 'project_files':len(after),'starts':2}
(w/'fixtures.json').write_text(json.dumps(summary,indent=2))
