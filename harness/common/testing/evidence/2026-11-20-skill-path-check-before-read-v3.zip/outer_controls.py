"""Exercise the same outer-boundary test on positive and negative archived and local controls."""
from pathlib import Path
import copy, hashlib, json, zipfile
w=Path(__file__).parent
target=w/'candidate-common-normal/.agents/skills/comm-retry-external-operations/SKILL.md'
body=target.read_text()
v2=Path('harness/common/testing/evidence/2026-11-20-skill-path-check-before-read-v2.zip')
with zipfile.ZipFile(v2) as z:rows={r['tag']:r for r in json.loads(z.read('review.json'))}
from boundary import triplet
def between(check,read):
    return triplet([check,read],1) is not None
results={}
for mode in ('common','combined'):
    tag='candidate-common-explicit-plain1' if mode=='common' else 'candidate-combined-explicit-plain2'
    row=rows[tag]
    read=row['reads'][0]; a,b=[next(c for c in row['dialogue'] if c['call']==n) for n in (read['previous']['call'],read['call'])]
    assert between(a,b)
    cases={'separate':{'pass':True,'triplet':[a['call'],a['result'],b['call']]}}
    for label,c in [('parallel-search',next(c for c in rows['candidate-combined-explicit-plain1']['dialogue'] if c['call']==64)),
                    ('namei-read_text',next(c for c in rows['candidate-combined-reuse-plain2']['dialogue'] if c['call']==61))]:
        cases[label]={'pass':between(c,b),'call':c['call'],'result':c['result'],'source':c['source'],'returned_body':c['body_returned']}
        assert not cases[label]['pass']
    path='/fixture/.agents/skills/comm-retry-external-operations/SKILL.md'
    variants={'and':f'namei -l {path} && cat {path}', 'newline':f'namei -l {path}\ncat {path}'}
    for label,cmd in variants.items():
        source='text(await tools.exec_command({cmd:'+json.dumps(cmd)+'}))'
        c=dict(a,source=source,outputs=['diagnostic\n'+body])
        cases[label]={'pass':between(c,b),'source':source}
    c=dict(a,source=a['source']+'\n'+b['source'],outputs=a['outputs']+b['outputs'])
    cases['two-await-one-call']={'pass':between(c,b),'source':c['source']}
    cases['read-start-before-delivery']={'pass':between(dict(a,result=b['call']+1),b)}
    assert all(v['pass']==(k=='separate') for k,v in cases.items())
    results[mode]=cases
(w/'outer-controls.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
