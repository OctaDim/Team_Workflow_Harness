from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess, sys
root=Path(__file__).parent
cases=[(mode,case,'extra') for case in ('file-link','dir-link','ambiguous','actions','timer','implicit','csv') for mode in ('common','combined')]
cases += [(mode,case,repeat) for repeat in ('one','two') for mode in ('common','combined') for case in ('explicit','reuse')]
def run(row):
    return subprocess.run([sys.executable,str(root/'native-recorded.py'),'candidate',*row]).returncode
with ThreadPoolExecutor(max_workers=6) as pool:
    results=list(pool.map(run,cases))
sys.exit(int(any(results)))
