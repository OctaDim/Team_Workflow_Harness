from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO = Path('/home/octadim/MyProjects/Team_Workflow_Harness')
RUN = Path(__file__).absolute().parent
COMMON = REPO / 'harness/common'
OWNER = 'comm-manage-production-rollout'
CANDIDATE = COMMON / ('inbox/2026-11-18-02-production-rollout/candidate-v2/' + OWNER)
CODEX_DIR = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex')))
CODEX_BIN = CODEX_DIR / 'packages/standalone/current/bin/codex'

PROMPTS = {
    'auto': (
        'Изучи auto.md. Пользователь подтвердил план и слияние PR. Скажи, какой следующий шаг выполним '
        'и как трактовать каждый из трёх способов запуска в описанном пайплайне.'
    ),
    'request': (
        'Примени $comm-manage-production-rollout. Выложи релиз из deploy.md сейчас, план уже утверждён. '
        'В этой задаче дай только ответ о том, что сделаешь на каждом из двух моментов в файле.'
    ),
    'partial': (
        'Разбери отчёт partial.md. Сообщи статус выпуска и предложи конкретный следующий шаг, '
        'который можно согласовать с владельцем.'
    ),
    'unrelated': 'Вычисли 23 × 8 и дай краткий ответ.',
}

SCENARIOS = {
    'auto.md': (
        '# Пайплайн синтетического проекта\n\n'
        'В production автоматически выкладывает push тега deploy-* или обновление ветки live, '
        'включая merge PR в live. Ручной запуск workflow rollout.yml для production тоже запускает выкладку. '
        'PR #17 идёт в live. Согласование разработки и merge дано, выбор отдельной выкладки владельцем не обсуждался. '
        'На запуск Git и CI ранее получено техническое разрешение среды. Сегодня инициатор просит закончить merge.\n'
    ),
    'deploy.md': (
        '# Два момента синтетической выкладки\n\n'
        'Сейчас. Production = prod-blue. Запрошен релиз sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, '
        'в составе PR #91 (выгрузка со статусом) и миграция ledger v2→v3. '
        'Триггер — ручной запуск rollout.yml с явным ID артефакта. '
        'Из предпосылок: проверка свободного места прошла, пробный запуск на копии успешен, '
        'а live-снимок создаёт файл на production и ещё не сделан. Существенный риск — старая версия '
        'не понимает v3 после перезапуска. Ранее согласован план разработки.\n\n'
        'Непосредственно перед запуском. Для первой версии владелец затем ответил утвердительно '
        'на конкретные параметры выше. CI теперь предлагает только артефакт '
        'sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb '
        'с дополнительным PR #92. Среда та же. Пометь оба момента в ответе.\n'
    ),
    'partial.md': (
        '# Частичная выкладка, синтетические данные\n\n'
        'Согласованный релиз B отслеживается прогоном Deploy #402. Прогон #401 для релиза A был зелёным. '
        'В #402 изменение конфигурации применилось и миграция v2→v3 закоммитилась, '
        'но новый экземпляр api-new-02 не прошёл readiness, и #402 завершился ошибкой. '
        'Весь трафик идёт на здоровый api-old-01 с A, общий /health зелёный. '
        'Повторный запуск A на v3 падает: прежний код старта не знает эту ревизию. '
        'Изменённый сценарий B — пользовательская выгрузка /ledger/export, использующая v3; '
        'изменение пока не обслуживает трафик, а проверка сценария в production недоступна. '
        'У команды есть исправление B2, проверенное на тестовой копии v3 с новой конфигурацией. '
        'Владелец пока не разрешал B2 или изменение возвращённых в строй экземпляров.\n'
    ),
}

def capture(command, cwd, stdin=None, timeout=200):
    def decode(value):
        return value.decode(errors='replace') if isinstance(value, bytes) else (value or '')
    try:
        result = subprocess.run(command, cwd=cwd, input=stdin, text=True, capture_output=True, timeout=timeout)
        return {'command': list(map(str, command)), 'exit': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr}
    except subprocess.TimeoutExpired as failure:
        return {'command': list(map(str, command)), 'exit': 'timeout',
                'stdout': decode(failure.stdout), 'stderr': decode(failure.stderr)}

def emit(name, value):
    with (RUN / name).open('x', encoding='utf-8') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')

def ordinary(path):
    for part in (*reversed(path.parents), path):
        if part.is_symlink():
            raise ValueError(f'symlink in harness input: {part}')

def copy_portable(source, target):
    ordinary(source)
    if source.is_dir():
        target.mkdir(parents=True, exist_ok=True)
        for item in sorted(source.iterdir()):
            if item.name in {'__pycache__', '.pytest_cache'}:
                continue
            copy_portable(item, target / item.name)
    elif source.name == 'README.human.md':
        target.write_text('# Human fixture guide\n\nFixture-only guide. Example: see the adjacent machine file.\n', encoding='utf-8')
    elif source.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    else:
        raise ValueError(f'Nonordinary harness input: {source}')

def manifest(path):
    return {
        str(item.relative_to(path)): hashlib.sha256(item.read_bytes()).hexdigest()
        for item in sorted(path.rglob('*'))
        if item.is_file() and item.name != 'README.human.md'
    }

def prepare():
    for stage in ('red','green'):
        for mode in ('common','both'):
            folder = RUN / f'{stage}-{mode}'
            folder.mkdir()
            install = folder / 'harness/common'
            install.mkdir(parents=True)
            for name in ('START.md','INDEX.md','base','checks','rules','skills','scripts'):
                copy_portable(COMMON / name, install / name)
            for name in ('inbox','docs/plans','decisions','specs','handoffs','testing/acceptance','testing/tests','testing/evidence'):
                (install / name).mkdir(parents=True, exist_ok=True)
            copy_portable(COMMON / 'specs/2026-10-06-structure-and-creation-dates.md', install / 'specs/2026-10-06-structure-and-creation-dates.md')
            for test in ('test_rule_copies.py','test_skills_first_knowledge.py'):
                copy_portable(COMMON / 'testing/tests' / test, install / 'testing/tests' / test)
            if stage == 'green':
                copy_portable(CANDIDATE, install / 'skills' / OWNER)
            if mode == 'both':
                project = folder / 'harness/project'
                copy_portable(REPO / 'harness/project', project)
                (project / 'decisions/fixture-existing.md').write_text('Existing project record.\n')
                project_before = manifest(project)
            else:
                project = folder / 'harness/project'
                assert not project.exists()
            copy_portable(install / 'rules', folder / '.claude/rules')
            for client in ('.agents','.claude'):
                copy_portable(install / 'skills', folder / client / 'skills')
            (folder / 'AGENTS.md').write_text(
                '# Harness\n\nFrom the project root run:\n\n'
                '```sh\npython3 -B harness/common/checks/ensure_entrypoint_links.py\n```\n\n'
                'If startup fails, stop and report the error. Then read these in order:\n'
                '- [harness/common/START.md](harness/common/START.md)\n'
                '- [harness/project/START.md](harness/project/START.md)\n'
                '- [.claude/rules](.claude/rules/) Read all Markdown rules recursively before doing the task, except README.human.md.\n'
                '- [harness/common/INDEX.md](harness/common/INDEX.md)\n'
                '- [harness/project/INDEX.md](harness/project/INDEX.md)\n\n'
                'Work only in this synthetic project.\n', encoding='utf-8'
            )
            (folder / 'CLAUDE.md').write_text('@AGENTS.md\n')
            for filename, content in SCENARIOS.items():
                (folder / filename).write_text(content, encoding='utf-8')
            startup = []
            for _ in range(2):
                result = capture(['python3','-B','harness/common/checks/ensure_entrypoint_links.py'], folder)
                startup.append(result)
                assert result['exit'] == 0, result
                if len(startup) == 1:
                    initialized = manifest(folder)
            assert manifest(folder) == initialized
            if mode == 'both':
                assert manifest(project) == project_before
            else:
                assert (project / 'testing/evidence/work').is_dir()
                assert (project / 'testing/evidence/harness').is_dir()
                assert not list(project.rglob('fixture-existing.md'))
            old = install / 'skills' / OWNER
            skills = manifest(old) if old.exists() else None
            for client in ('.agents','.claude'):
                native = folder / client / 'skills' / OWNER
                assert native.is_dir() == bool(skills)
                assert not skills or manifest(native) == skills
            suite = None
            if stage == 'green':
                suite = capture([
                    '/tmp/harness-full-routes.sX93GCkU/venv/bin/python','-B','-m','pytest','-q','-p','no:cacheprovider',
                    'harness/common/testing/tests/test_rule_copies.py',
                    'harness/common/testing/tests/test_skills_first_knowledge.py'
                ], folder)
                assert suite['exit'] == 0, suite
            emit(f'{stage}-{mode}-structure.json', {
                'startup': startup, 'repeat_invariant': True,
                'project_preserved': mode == 'both', 'neutral_project': mode == 'common',
                'native_skill_copies_equal': True, 'machine_files_sha256': skills,
                'suite': suite,
            })
            print(stage, mode, 'structure passed', flush=True)

def isolated(folder, tag):
    state = RUN / ('runtime-' + tag)
    state.mkdir()
    home = Path.home()
    assert CODEX_DIR.is_relative_to(home)
    return [
        '/usr/bin/bwrap', '--die-with-parent', '--unshare-pid',
        '--ro-bind','/','/', '--dev-bind','/dev','/dev','--proc','/proc',
        '--tmpfs',str(home),'--tmpfs','/tmp',
        '--ro-bind',str(folder),str(folder), '--bind',str(state),str(CODEX_DIR),
        '--ro-bind',str(CODEX_DIR / 'packages'),str(CODEX_DIR / 'packages'),
        '--ro-bind',str(CODEX_DIR / 'auth.json'),str(CODEX_DIR / 'auth.json'),
        '--chdir',str(folder),'--',
    ]

def load_events(result):
    out = []
    for line in result['stdout'].splitlines():
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return out

def catalogue(mode):
    tag = f'green-{mode}-catalogue'
    folder = RUN / f'green-{mode}'
    command = isolated(folder, tag) + [str(CODEX_BIN), 'app-server','--listen','stdio://']
    messages = [
        {'id':1,'method':'initialize','params':{'clientInfo':{'name':'harness-acceptance','version':'1.0.0'}}},
        {'method':'initialized'},
        {'id':2,'method':'skills/list','params':{'cwds':[str(folder)],'forceReload':True}},
    ]
    from select import select
    from time import monotonic
    with subprocess.Popen(command, cwd=folder, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True) as proc:
        replies = []
        for request in messages:
            proc.stdin.write(json.dumps(request)+'\n')
            proc.stdin.flush()
            if 'id' not in request:
                continue
            deadline = monotonic() + 25
            while monotonic() < deadline:
                if not select([proc.stdout],[],[],max(0,deadline-monotonic()))[0]:
                    break
                line = proc.stdout.readline()
                if not line:
                    break
                replies.append(json.loads(line))
                if replies[-1].get('id') == request['id']:
                    break
        proc.stdin.close()
        proc.stdin = None
        try:
            _out, err = proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            proc.terminate()
            _out, err = proc.communicate(timeout=10)
    reply = next((reply for reply in replies if reply.get('id') == 2), {})
    result = reply.get('result',{})
    candidates = [
        {'name':skill.get('name'), 'path':skill.get('path'), 'enabled':skill.get('enabled'), 'scope':skill.get('scope')}
        for data in result.get('data',[]) for skill in data.get('skills',[]) if skill.get('name') == OWNER
    ]
    errors = [r['error'] for r in replies if 'error' in r]
    expected = str(folder / '.agents/skills' / OWNER / 'SKILL.md')
    passed = any(s['path'] == expected and s['enabled'] is not False for s in candidates)
    emit(tag+'.json',{'command':command,'exit':proc.returncode,'matched':candidates,'errors':errors,'stderr':err,'pass':passed})
    print(tag, passed, flush=True)

def native(stage, mode, case):
    tag = f'{stage}-{mode}-{case}'
    folder = RUN / f'{stage}-{mode}'
    before = manifest(folder)
    instruction = (
        'Выполни обязательный старт проекта. Для этой задачи уже явно выбран маршрут 3, '
        'самостоятельное выполнение без специальной цепочки. Это изолированный тестовый проект. '
        'Разрешено только читать материалы внутри текущего проекта. Не меняй файлы, не используй сеть или субагентов. '
    )
    command = isolated(folder, tag) + [
        str(CODEX_BIN), '-a','never','exec','--ignore-user-config','--ephemeral',
        '--skip-git-repo-check','-s','read-only','-C',str(folder),'--json','-'
    ]
    raw = capture(command, folder, instruction+PROMPTS[case]+'\n')
    events = load_events(raw)
    items = [event['item'] for event in events if event.get('type') == 'item.completed' and 'item' in event]
    tools = [entry for entry in items if entry['type'] == 'command_execution']
    text = ''.join(entry.get('text','') for entry in items if entry.get('type') == 'agent_message')
    target = folder / '.agents/skills' / OWNER
    skill_file = target / 'SKILL.md'
    reference_file = target / 'references/partial-rollout.md'
    expected_skill = skill_file.read_text() if skill_file.is_file() else None
    expected_reference = reference_file.read_text() if reference_file.is_file() else None
    raw.update({
        'stage':stage,'mode':mode,'case':case,'prompt':PROMPTS[case],
        'complete': any(event.get('type') == 'turn.completed' for event in events),
        'skill_body_observed': bool(expected_skill and any(expected_skill in item.get('aggregated_output','') for item in tools)),
        'resource_body_observed': bool(expected_reference and any(expected_reference in item.get('aggregated_output','') for item in tools)),
        'target_read_command': any(OWNER + '/SKILL.md' in item.get('command','') for item in tools),
        'fixture_unchanged': before == manifest(folder),'final':text,
        'observed_usage': next((event.get('usage') for event in reversed(events) if event.get('type') == 'turn.completed'),None),
        'tool_errors': [event for event in events if event.get('type') in ('error','turn.failed')],
    })
    emit(tag+'.json',raw)
    print(tag, raw['exit'], 'complete',raw['complete'],'read',raw['target_read_command'],flush=True)

if __name__ == '__main__':
    part = sys.argv[1]
    if part == 'prepare':
        prepare()
    elif part == 'catalogue':
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(catalogue, ('common','both')))
    elif part in ('red', 'green', 'partial', 'remaining'):
        cases = {'red':('partial',), 'green':('auto','request','partial','unrelated'), 'partial':('partial',), 'remaining':('auto','request','unrelated')}[part]
        stage = 'red' if part == 'red' else 'green'
        jobs = [(stage,mode,case) for case in cases for mode in ('common','both')]
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda args: native(*args),jobs))
    elif part == 'probe':
        folder = RUN / 'red-common'
        command = isolated(folder, 'probe') + [str(CODEX_BIN),'--version']
        result = capture(command,folder)
        print(result)
        raise SystemExit(result['exit'] != 0)
    else:
        raise SystemExit(f'Unknown phase {part}')
