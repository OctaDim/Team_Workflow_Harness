from concurrent.futures import ThreadPoolExecutor
import native_probe

native_probe.PROMPTS['ordinary-pr'] = (
    'Выбран обычный черновой PR для объединения изменений документации из docs/fix-link в review-docs. '
    'Пользователь просит в чате описать подготовку и проверку такого PR. '
    'Слияние и запуск CI в поручение не входят. Обе ветки документационные и ни одна операция '
    'с этим черновиком не запускает production. Ответь по доступным правилам проекта.'
)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(lambda mode: native_probe.native('green',mode,'ordinary-pr'), ('common','both')))
