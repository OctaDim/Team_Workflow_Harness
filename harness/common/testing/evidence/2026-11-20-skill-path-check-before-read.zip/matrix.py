import concurrent.futures,subprocess,sys
from pathlib import Path
w=Path(__file__).parent
def run(spec):
    return subprocess.run([sys.executable,str(w/'native.py'),*spec,'matrix'],check=False).returncode
edition=sys.argv[1]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,[(edition,mode,case) for case in ('explicit','actions','timer','reuse','dir-link','file-link','ambiguous','implicit','csv') for mode in ('common','combined')]))
sys.exit(int(any(results)))
