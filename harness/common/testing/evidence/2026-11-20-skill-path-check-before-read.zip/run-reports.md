# Нативные свидетельства по каждому запуску

Метка matrix обозначает журнал команд CLI, detail — отдельную сессию с записями ответов инструмента модели. Строгий счётчик не засчитывает неполученный список. В отрицательном сценарии обязательная остановка может наступить до окончания старта. В таком случае приводится фактически достигнутое покрытие. Ни одна нативная сессия не передаёт оценку другой версии.

## Старт текущей рабочей сессии

- Впервые через START — 2
- Впервые через AGENTS — 10
- Размер списка — 12
- Уникальных прочитанных — 12
- Лишних полных чтений — 0
- Результат — прочитано 12 из 12.

## base · combined · actions · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · combined · ambiguous · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — в ответе агента указан отказ доступа; журнал команд CLI не показывает результат диагностики.

## base · combined · csv · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · combined · dir-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · combined · explicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; первое отдельное чтение после обоих INDEX не подтверждено.

## base · combined · file-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 0
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 11
- Повторно прочитанных правил: 0
- Результат: Ошибка - до INDEX не подтверждены полные тексты: .claude/rules/comm-human-folder-guides.md, .claude/rules/comm-skill-rule-ownership.md, прочтено 11 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · combined · implicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-assess-project-tests/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; первое отдельное чтение после обоих INDEX не подтверждено.

## base · combined · reuse · matrix

- Правила `.claude/rules/` через ссылки в START.md: 3
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; не подтверждено раннее чтение по применимой ссылке.

## base · combined · timer · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · actions · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · ambiguous · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-resolve-permission-blockers/SKILL.md, прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — в ответе агента указан отказ доступа; журнал команд CLI не показывает результат диагностики.

## base · common · csv · matrix

- Правила `.claude/rules/` через ссылки в START.md: 1
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 11
- Повторно прочитанных правил: 0
- Результат: Ошибка - до INDEX не подтверждены полные тексты: .claude/rules/comm-skill-rule-ownership.md, прочтено 11 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · common · dir-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · common · explicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · file-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · common · implicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · reuse · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; не подтверждено раннее чтение по применимой ссылке.

## base · common · timer · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## candidate · combined · actions · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · ambiguous · matrix

- Правила `.claude/rules/` через ссылки в START.md: нет данных
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: нет данных
- Всего правил в `.claude/rules/`: нет данных
- Всего правил прочитано: нет данных
- Повторно прочитанных правил: нет данных
- Результат: Ошибка - прочитано правило вне ссылок START до перечисления: .claude/rules/comm-application-config-git.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-application-startup-readiness.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-ban-harness-symlinks.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-confirm-development-workflow.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-dependencies-through-uv.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-entrypoint-links-rule.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-instruction-order.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-package-independence.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-task-commit-on-completion.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-training.md, нет отдельного подтверждённого полного списка правил, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — в ответе агента указан отказ доступа; журнал команд CLI не показывает результат диагностики.

## candidate · combined · csv · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · dir-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · explicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; первое отдельное чтение после обоих INDEX не подтверждено.

## candidate · combined · file-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · implicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-assess-project-tests/SKILL.md. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## candidate · combined · reuse · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — после INDEX файл вновь открыт для сравнения или хеширования.

## candidate · combined · timer · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · actions · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · ambiguous · matrix

- Правила `.claude/rules/` через ссылки в START.md: нет данных
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: нет данных
- Всего правил в `.claude/rules/`: нет данных
- Всего правил прочитано: нет данных
- Повторно прочитанных правил: нет данных
- Результат: Ошибка - прочитано правило вне ссылок START до перечисления: .claude/rules/comm-instruction-order.md, прочитано правило вне ссылок START до перечисления: .claude/rules/comm-training.md, нет отдельного подтверждённого полного списка правил, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — в ответе агента указан отказ доступа; журнал команд CLI не показывает результат диагностики.

## candidate · common · csv · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · dir-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 13 из 13. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · explicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · file-link · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · implicit · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## candidate · common · reuse · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - повторное полное чтение неизменного скилла: harness/common/skills/comm-retry-external-operations/SKILL.md; сообщить ошибку и путь, запросить решение пользователя и ждать ответа. Проверка поведения — повторно выдан текст той же версии.

## candidate · common · timer · matrix

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## base · combined · actions · detail

- Правила `.claude/rules/` через ссылки в START.md: 3
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 9
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · combined · ambiguous · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-resolve-permission-blockers/SKILL.md. Проверка поведения — отказ доступа подтверждён в записи ответа модели, вызова чтения целевого файла нет.

## base · combined · explicit · detail

- Правила `.claude/rules/` через ссылки в START.md: 3
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 9
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; первое отдельное чтение после обоих INDEX не подтверждено.

## base · combined · reuse · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; не подтверждено раннее чтение по применимой ссылке.

## base · common · actions · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · ambiguous · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-resolve-permission-blockers/SKILL.md, прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — отказ доступа подтверждён в записи ответа модели, вызова чтения целевого файла нет.

## base · common · explicit · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## base · common · reuse · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Ошибка - необоснованное, неполное или совмещённое чтение скилла: harness/common/skills, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, до INDEX не подтверждены полные тексты: .claude/rules/comm-task-commit-on-completion.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md, прочтено 12 из 13, не прочитаны нужные для задачи скиллы: harness/common/skills/comm-retry-external-operations/SKILL.md, нет подтверждённого открытия скилла. Проверка поведения — нет отдельного чтения полного актуального текста владельца; полный текст получен в совмещённом вызове; не подтверждено раннее чтение по применимой ссылке.

## candidate · combined · actions · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · ambiguous · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — отказ доступа подтверждён в записи ответа модели, вызова чтения целевого файла нет.

## candidate · combined · explicit · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · combined · reuse · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, повторное полное чтение неизменного скилла: harness/common/skills/comm-retry-external-operations/SKILL.md; сообщить ошибку и путь, запросить решение пользователя и ждать ответа. Проверка поведения — повторно выдан текст той же версии.

## candidate · common · actions · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — критерий поведения в данном сценарии выполнен.

## candidate · common · ambiguous · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 8
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 10
- Повторно прочитанных правил: 0
- Результат: Ошибка - прочтено 10 из 13, нет отдельного чтения обязательных INDEX перед скиллом. Проверка поведения — отказ доступа подтверждён в записи ответа модели, вызова чтения целевого файла нет.

## candidate · common · explicit · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 10
- Всего правил в `.claude/rules/`: 12
- Всего правил прочитано: 12
- Повторно прочитанных правил: 0
- Результат: Успешно - прочтено 12 из 12. Проверка поведения — не подтверждена самостоятельная пара «проверка того же пути → чтение».

## candidate · common · reuse · detail

- Правила `.claude/rules/` через ссылки в START.md: 2
- Правила `.claude/rules/` через ссылку на `.claude/rules/` в AGENTS.md: 11
- Всего правил в `.claude/rules/`: 13
- Всего правил прочитано: 13
- Повторно прочитанных правил: 0
- Результат: Ошибка - пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, пропущен переход по применимой ссылке: harness/common/skills/comm-retry-external-operations/SKILL.md, необоснованное, неполное или совмещённое чтение скилла: harness/common/skills/comm-retry-external-operations/SKILL.md. Проверка поведения — после INDEX файл вновь открыт для сравнения или хеширования.

## Предварительные попытки запуска

До основной матрицы три технические попытки не достигли чтения правил: ошибка монтирования бинарника, недоступный транспорт, затем недоступный code-mode-host. После настройки стенда запущена полная матрица выше. Эти попытки не входят в 52 сессии сравнения.

### base · common · explicit · initial

- Впервые через START — 0
- Впервые через AGENTS — 0
- Размер полученного списка — список не получен
- Уникальных прочитанных — 0
- Лишних полных чтений — 0
- Результат — сценарий не начат.

### base · common · explicit · isolated

- Впервые через START — 0
- Впервые через AGENTS — 0
- Размер полученного списка — список не получен
- Уникальных прочитанных — 0
- Лишних полных чтений — 0
- Результат — сценарий не начат.

### base · common · explicit · approved

- Впервые через START — 0
- Впервые через AGENTS — 0
- Размер полученного списка — список не получен
- Уникальных прочитанных — 0
- Лишних полных чтений — 0
- Результат — сценарий не начат.
