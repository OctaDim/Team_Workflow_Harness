from pathlib import Path
import json, os, shutil, subprocess, sys
w=Path(__file__).parent
edition,mode,case,label=sys.argv[1:]
fixture_case='normal' if case in ('explicit','timer','actions','implicit','csv') else case
r=w/f'{edition}-{mode}-{fixture_case}'
tag=f'{edition}-{mode}-{case}-{label}'
profile=w/(tag+'-profile')
profile.mkdir(mode=0o700)
cli=Path.home()/'.codex'
binary=cli/'packages/standalone/current/bin/codex'
args=['bwrap','--die-with-parent','--unshare-pid','--clearenv',
      '--setenv','HOME','/home/runner','--setenv','PATH','/opt:/usr/bin:/bin',
      '--setenv','LANG','C.UTF-8','--ro-bind','/usr','/usr']
for alias in ('bin','lib','lib64','sbin'):
    if (Path('/')/alias).is_symlink():args+=['--symlink',os.readlink('/'+alias),'/'+alias]
args+=['--dir','/etc','--ro-bind','/etc/ssl','/etc/ssl','--ro-bind','/etc/resolv.conf','/etc/resolv.conf',
       '--dev','/dev','--proc','/proc','--tmpfs','/tmp',
       '--bind',str(profile),'/home/runner/.codex',
       '--ro-bind',str(cli/'auth.json'),'/home/runner/.codex/auth.json',
       '--ro-bind',shutil.which('rg'),'/opt/rg','--ro-bind',str(binary.parent),'/opt/codex-bin','--ro-bind',str(r),'/fixture','--chdir','/fixture']
if case in ('actions','timer'):args+=['--ro-bind',str(w/('timer-schema.json' if case=='timer' else 'schema.json')),'/tmp/response.json']
args+=['--','/opt/codex-bin/codex','-a','never','exec','--ignore-user-config','--skip-git-repo-check','--ephemeral','-C','/fixture','--sandbox','read-only','-m','gpt-6.2-sol','-c','features.multi_agent=false','-c','model_reasoning_effort="medium"','--json']
if case in ('actions','timer'):args+=['--output-schema','/tmp/response.json']
args.append(json.loads((w/'prompts.json').read_text())[case])
with (w/f'{tag}.jsonl').open('xb') as out,(w/f'{tag}.stderr').open('xb') as err:
    try: code=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=360).returncode
    except subprocess.TimeoutExpired:code=124
print(tag,code)
sys.exit(code)
