"""Real shell output for the two bad command forms, separate events, and bounded continuation."""
from pathlib import Path
import json,shlex,subprocess,zipfile
from audit import canonical, checked_path, lib, tokens, w, parse
out={}
for mode in ('common','combined'):
 r=w/f'candidate-{mode}-normal'
 body=(r/canonical).read_text()
 def command(cmd, start, cwd=r):
    result=subprocess.run(['bash','-c',cmd],cwd=cwd,text=True,capture_output=True)
    return dict(start_event=start,end_event=start+1,command=cmd,aggregated_output=result.stdout+result.stderr,exit_code=result.returncode)
 probe='namei -l '+canonical
 read='cat '+canonical
 def paired(tools):
    if len(tools)<2:return False
    prev,last=tools[-2:]
    return prev['end_event'] < last['start_event'] and checked_path(prev,canonical) and bool(lib['skill_read_lines'](tokens(last),canonical,last['aggregated_output'],body))
 cases={'and':[command(probe+' && '+read,1)],'newline':[command(probe+'\n'+read,1)],
        'separate':[command(probe,1),command(read,3)],
        'overlap':[command(probe,1),command(read,2)],
        'fragment':[command(probe,1),command('head -n 5 '+canonical,3),command(probe,5),command('tail -n +6 '+canonical,7)]}
 for label,records in cases.items():
    if label=='fragment':
        records[-1]=command("sed -n '6,$p' "+canonical,7)
        assert paired(records[:2]) and paired(records[2:]) and records[1]['aggregated_output']+records[3]['aggregated_output']==body
    else: assert paired(records)==(label=='separate'),label
 out[mode]=cases
with zipfile.ZipFile('harness/common/testing/evidence/2026-11-20-external-retries-after-explicit-skill-rule.zip') as z:
 for c in ('explicit','actions','timer'):
    events=list(map(json.loads,z.read('traces/common-'+c+'.jsonl').splitlines()))
    ids=(37,) if c=='explicit' else (35,) if c=='actions' else (35,37,39)
    out['archive-'+c]=[{'event':i,'command':events[i-1]['item']['command'],'has_full_body':body in events[i-1]['item']['aggregated_output']} for i in ids]
    assert out['archive-'+c][0]['has_full_body']==(c!='timer')
(w/'controls.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print('both modes: &&, newline, positive, overlapping events, same-version slices')
