from pathlib import Path
import json,subprocess
w=Path(__file__).parent
results={}
for edition in ('base','candidate'):
 for mode in ('common','combined'):
  root=w/f'{edition}-{mode}-normal'
  cmd=['bwrap','--die-with-parent','--clearenv','--setenv','HOME','/home/runner','--setenv','PATH','/usr/bin','--ro-bind','/usr','/usr','--symlink','usr/bin','/bin','--symlink','usr/lib','/lib','--symlink','usr/lib64','/lib64','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--dir','/home/runner','--ro-bind',str(Path.home()/'.codex/packages/standalone/current/bin'),'/opt/bin','--ro-bind',str(root),'/fixture','--chdir','/fixture','--','/opt/bin/codex','app-server','--listen','stdio://']
  p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=None,text=True)
  def send(d):
   p.stdin.write(json.dumps(d)+'\n');p.stdin.flush()
  def reply(i):
   for line in p.stdout:
    d=json.loads(line)
    if d.get('id')==i:return d['result']
   raise ValueError('catalogue closed before response')
  try:
   send(dict(id=1,method='initialize',params={'clientInfo':{'name':'harness-validation','version':'1'}}));reply(1)
   send(dict(method='initialized'))
   send(dict(id=2,method='skills/list',params={'cwds':['/fixture'],'forceReload':True}));d=reply(2)['data'][0]
   native=[s for s in d['skills'] if s['scope']=='repo']
   owner=[s for s in native if s['name']=='comm-retry-external-operations']
   assert len(owner)==1 and owner[0]['enabled'] and owner[0]['path']=='/fixture/.agents/skills/comm-retry-external-operations/SKILL.md',owner
   assert not d['errors'],d['errors']
   guards=[root/'AGENTS.md',*root.glob('harness/*/START.md'),*root.glob('harness/*/INDEX.md'),*root.glob('.claude/rules/comm-*.md')]
   results[root.name]=dict(owner=owner[0]['path'],count=len(native),metadata_bytes=sum(len((s['name']+s['description']).encode()) for s in native),guard_bytes=sum(f.stat().st_size for f in guards))
  finally:
   p.stdin.close();p.terminate();p.wait(timeout=10)
print(json.dumps(results,indent=2))
