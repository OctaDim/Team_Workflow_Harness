from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
w=Path(__file__).parent
def run(entry):
    return subprocess.run([sys.executable,str(w/'native-recorded.py'),*entry,'detail']).returncode
cases=[(v,m,c) for v in ('candidate','base') for c in ('ambiguous','explicit','actions','reuse') for m in ('common','combined')]
with ThreadPoolExecutor(max_workers=4) as pool:sys.exit(int(any(list(pool.map(run,cases)))))
