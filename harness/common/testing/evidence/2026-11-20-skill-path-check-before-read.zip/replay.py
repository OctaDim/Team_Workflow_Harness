"""Execute a native client's selected actions against a synthetic supplier and clock."""
import json
import sys
from pathlib import Path

def replay(case, actions):
    left = 2 if case == 'slow' else 8
    wait = 12 if case == 'hint' else 1
    timeout = 4
    writes = int(case in ('lost', 'stale', 'allowed'))
    initial = writes
    sends = int(case == 'sdk') * 3
    now = 0
    result = None
    confirmed = False
    looked = False
    for action in actions:
        assert result is None
        if action == 'lookup':
            assert case in ('lost','stale','allowed')
            looked = True
            confirmed = case == 'lost'
        elif action == 'wait':
            now += wait
            assert now < left
        elif action == 'cap_timeout':
            timeout = min(timeout, left-now)
        elif action == 'send':
            assert now < left
            if case in ('recover','allowed'):
                assert now >= wait
            sends += 1
            if case == 'slow':
                now += timeout
                assert now <= left
            else:
                writes += int(case != 'allowed' or writes == 0)
                confirmed = True
        else:
            result = action
    expected = {'lost':('report_success',1,0),'stale':('report_unknown',1,0),
                'recover':('report_success',1,1),'slow':('timeout',0,1),
                'abort':('cancel',0,0),'bad':('reject',0,0),'sdk':('exhaust',0,3),
                'hint':('exhaust',0,0),'allowed':('report_success',1,1)}
    assert (result,writes,sends)==expected[case]
    if case in ('lost','stale'): assert looked
    if result == 'report_success': assert confirmed
    if case == 'slow': assert now==2
    return {'result':result,'physical_sends':sends,'initial_writes':initial,'final_writes':writes,'elapsed':now}

if __name__=='__main__':
    p=Path(__file__).parent
    for name in sys.argv[1:]:
        cases=json.loads((p/(name+'.decision')).read_text())
        report={}
        for case,actions in cases.items():
            try: report[case]=dict(passed=True,**replay(case,actions))
            except AssertionError: report[case]=dict(passed=False,actions=actions)
        (p/(name+'-replay.json')).write_text(json.dumps(report,indent=2)+'\n')
        print(name, [c for c in report if not report[c]['passed']])
