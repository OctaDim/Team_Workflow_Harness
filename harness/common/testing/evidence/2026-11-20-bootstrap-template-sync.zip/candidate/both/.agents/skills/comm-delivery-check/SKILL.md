---
name: comm-delivery-check
description: Check an ambiguous delivery receipt.
---
Перед принятием решения проверь квитанцию по идентификатору документа.
