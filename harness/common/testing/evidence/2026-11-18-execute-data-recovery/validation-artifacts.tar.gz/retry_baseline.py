import native_probe

native_probe.PROMPTS['rehearsal-retry'] = native_probe.PROMPTS['rehearsal']
native_probe.native('red','both','rehearsal-retry')
