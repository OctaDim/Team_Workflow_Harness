import native_probe

native_probe.PROMPTS['production-retry'] = native_probe.PROMPTS['production']
native_probe.native('green','both','production-retry')
