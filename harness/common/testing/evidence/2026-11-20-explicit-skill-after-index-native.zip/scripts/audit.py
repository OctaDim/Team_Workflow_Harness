from pathlib import Path
import json, hashlib, runpy, re
w=Path(__file__).parent
lib=runpy.run_path('harness/common/checks/check_human_guide_search.py')
hashfile=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def audit(p):
 tag=p.stem.rsplit('-',1)[0];r=w/tag
 events=[json.loads(l) for l in p.read_text().splitlines()]
 tools=[]; starts={}; replies=[]
 for n,e in enumerate(events,1):
  i=e.get('item',{})
  if i.get('type')=='command_execution':
   if e['type']=='item.started':starts[i['id']]=n
   elif e['type']=='item.completed':tools.append(dict(i,start_event=starts[i['id']],end_event=n))
  elif i.get('type')=='agent_message' and e['type']=='item.completed': replies.append((n,i['text']))
 canonical='harness/common/skills/comm-check-test-document/SKILL.md'
 body=(r/canonical).read_text();skill_hash=hashfile(r/canonical)
 expected,start_bodies,aliases=lib['snapshot_rule_inputs'](r)
 reuse=tag.endswith('-reuse');owner='.claude/rules/comm-training-document.md'
 skill_aliases=lib['installed_skill_aliases'](r,{canonical:body})
 index=['harness/common/INDEX.md','harness/project/INDEX.md']
 report=lib['assess_rule_reading'](tools,expected,starts=start_bodies,aliases=aliases,root=r,immutable_fixture=True,skill_bodies={canonical:body},skill_links={owner:{canonical:0}} if reuse else {},task_skills={canonical})
 commands=[];idx={i:[] for i in index}; skill=[];access=[];fragments=[];docs=[];owner_reads=[];lines=set()
 for i in tools:
  rawtokens=lib['command_tokens'](i['command'])
  tokens=[t.removeprefix(str(r)+'/').removeprefix('./') for t in rawtokens]
  out=i['aggregated_output']; a,b=i['start_event'],i['end_event']
  commands.append({'call':a,'result':b,'command':i['command'],'exit':i['exit_code']})
  if i['exit_code']:continue
  for name in index:
   pos=out.find((r/name).read_text())
   if pos!=-1 and name in tokens:idx[name].append((a,b,pos))
  if reuse and expected[owner] in out:owner_reads.append((a,b))
  if any(t in skill_aliases for t in tokens) or body in out:
   access.append((a,b))
   norm=[skill_aliases.get(t,t) for t in tokens];span=lib['skill_read_lines'](norm,canonical,out,body)
   if span is not None:
    fragments.append((a,b));lines.update(span)
    if len(lines)==len(body.splitlines()):skill.append((a,b));lines.clear()
  if 'D-17.txt' in tokens and (r/'D-17.txt').read_text() in out:docs.append((a,b))
 result=re.search('КВИТАНЦИЯ-[a-f0-9]+',body).group()+'=92'
 ix0=idx[index[0]];ix1=idx[index[1]]
 ordered=bool(ix0 and ix1 and (ix0[0][1]<ix1[0][0] or ix0[0][:2]==ix1[0][:2] and ix0[0][2]<ix1[0][2]))
 success=(events[-1]['type']=='turn.completed' and report['rule_reading_pass'] and ordered and len(skill)==1 and access==fragments and not lines and bool(docs) and docs[0][0]>max(ix1[-1][1],skill[0][1]) and bool(replies) and result in replies[-1][1] and (bool(owner_reads) and owner_reads[0][1]<fragments[0][0] and skill[0][1]<ix0[0][0] if reuse else ix1[-1][1]<fragments[0][0]))
 return dict(tag=tag,trace_sha256=hashfile(p),rule_sha256=hashfile(r/'.claude/rules/comm-instruction-order.md'),skill_sha256=skill_hash,agent_file_sha256=hashfile(r/'AGENTS.md'),case='reuse' if reuse else 'first',completed=events[-1]['type'],tools=commands,index=idx,skill_reads=skill,skill_accesses=access,document=docs,owner_reads=owner_reads,expected=result,reply=replies[-1] if replies else None,report=report,accepted=bool(success))
if __name__=='__main__':
 paths=sorted([*w.glob('*-control.jsonl'),*w.glob('*-acceptance.jsonl')]);out=[audit(p) for p in paths]
 print(json.dumps([{k:t[k] for k in ('tag','completed','accepted','skill_reads','document','reply')} | {'rules':t['report']['rule_read_report']} for t in out],ensure_ascii=False,indent=1))
 (w/'audited.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
