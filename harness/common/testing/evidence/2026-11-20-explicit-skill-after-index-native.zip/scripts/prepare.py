from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
w=Path(__file__).parent
source=Path.cwd()
candidate=source/'harness/common/inbox/2026-11-20-explicit-skill-after-index/comm-instruction-order-compact.md'
name='comm-check-test-document'
rel=Path('harness/common/skills')/name/'SKILL.md'
def tree(src,dest,ignore=()):
    shutil.copytree(src,dest,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','*.pyc',*ignore))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for mode in ('common','both'):
 for case in ('first','reuse'):
  variant=sys.argv[1]
  tag=f'{variant}-{mode}-{case}'
  r=w/tag
  r.mkdir()
  for p in ['AGENTS.md','CLAUDE.md','pytest.ini']:shutil.copyfile(source/p,r/p)
  for p in ['.agents','.claude']:tree(source/p,r/p)
  tree(source/'harness/common',r/'harness/common',('inbox','evidence'))
  if mode=='both':tree(source/'harness/project',r/'harness/project')
  for part in ['harness/common/rules','.claude/rules']:
   if variant!='base':shutil.copyfile(candidate,r/part/'comm-instruction-order.md')
   if case=='reuse':
    (r/part/'comm-training-document.md').write_text('При проверке учебного документа прочитай отдельным вызовом `.agents/skills/comm-check-test-document/SKILL.md` сразу после этого правила.\n')
  body='---\nname: comm-check-test-document\ndescription: Use when verifying a training document.\n---\nДля проверки документа D-17 прочитай файл D-17.txt. Сложи числа и сообщи сумму в формате КВИТАНЦИЯ-'+os.urandom(3).hex()+'=<сумма>.\n'
  for part in ['harness/common/skills','.agents/skills','.claude/skills']:
   d=r/part/name;d.mkdir();(d/'SKILL.md').write_text(body)
  (r/'D-17.txt').write_text('58\n34\n')
  def project_snapshot():
   return {str(p.relative_to(r)):digest(p) for p in (r/'harness/project').rglob('*') if p.is_file() and p.name!='README.human.md'}
  before=project_snapshot()
  subprocess.run(['python3','-B','harness/common/checks/ensure_entrypoint_links.py'],cwd=r,check=True,stdout=subprocess.DEVNULL)
  assert (mode=='common' and not before and project_snapshot()) or (mode=='both' and before==project_snapshot())
  assert digest(r/'AGENTS.md')==digest(source/'AGENTS.md')
  (w/(tag+'-profile')).mkdir()
  print(tag,digest(r/'.claude/rules/comm-instruction-order.md'),digest(r/rel))
