from pathlib import Path
import concurrent.futures, subprocess, sys
w=Path(__file__).parent
h=Path.home()
codex=h/'.codex'
def run(tag):
 r=w/tag
 run_id=tag+'-'+sys.argv[2]
 args=['bwrap','--die-with-parent','--ro-bind','/','/','--tmpfs','/home','--tmpfs','/tmp','--tmpfs','/mnt','--ro-bind','/mnt/wsl/resolv.conf','/mnt/wsl/resolv.conf','--dev','/dev','--proc','/proc','--bind',str(w/(tag+'-profile')),str(codex),'--ro-bind',str(codex/'auth.json'),str(codex/'auth.json'),'--ro-bind',str(codex/'packages'),str(codex/'packages'),'--ro-bind',str(r),str(r),'--chdir',str(r),'--',str(codex/'packages/standalone/current/bin/codex'),'-a','never','exec','--ignore-user-config','--skip-git-repo-check','-C',str(r),'-s','read-only','-m','gpt-6.2-sol','-c','features.multi_agent=false','-c','model_reasoning_effort="medium"','--json','Примени $comm-check-test-document к учебному документу D-17 и сообщи результат.']
 with (w/(run_id+'.jsonl')).open('xb') as o,(w/(run_id+'.err')).open('xb') as e:
  try:code=subprocess.run(args,cwd=r,stdin=subprocess.DEVNULL,stdout=o,stderr=e,timeout=420).returncode
  except subprocess.TimeoutExpired:code=124
 print(tag,code,flush=True)
 return code
tags=[f'{sys.argv[1]}-{m}-{c}' for m in ('common','both') for c in ('first','reuse')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 sys.exit(int(any(list(pool.map(run,tags)))))
