---
name: comm-check-test-document
description: Use when verifying a training document.
---
Для проверки документа D-17 прочитай файл D-17.txt. Сложи числа и сообщи сумму в формате КВИТАНЦИЯ-58ff4a=<сумма>.
