При проверке учебного документа прочитай отдельным вызовом `.agents/skills/comm-check-test-document/SKILL.md` сразу после этого правила.
