"""Capture model-facing event boundaries and independently compare delivered text with the owner."""
import hashlib,json,re
from pathlib import Path
from details import load_detail,w,canonical
body=(w/'candidate-common-normal'/canonical).read_text()
def review(p):
    d=load_detail(p)
    if not d:return
    r=d['cli_audit'];outer=d['calls']
    roll,=(w/(p.stem+'-profile')/'sessions').rglob('rollout-*.jsonl')
    pre=[]
    for n,line in enumerate(roll.open(),1):
        if n>=outer[0]['call']:break
        item=json.loads(line)['payload']
        for part in item.get('content',[]) if item.get('type')=='message' else []:
            text=part.get('text','')
            if body in text:
                path=re.search('<path>([^<]+)</path>',text)
                pre.append(dict(line=n,role=item.get('role'),path=path[1] if path else None,skill_message=text if text.startswith("<skill>") else None,body_sha256=hashlib.sha256(body.encode()).hexdigest()))
    reads=[]
    for j,c in enumerate(outer):
        if c['body_returned']:
            exact=any(s==body for s in c['outputs'])
            prev=outer[j-1] if j else {}
            reads.append(dict(call=c['call'],result=c.get('result'),exact=exact,source=c['source'],previous={k:prev.get(k) for k in ['call','result','source','outputs']}))
    return dict(tag=p.stem,preload=pre,reads=reads,dialogue=d['calls'],cli=r,prompt=json.loads((w/'prompts.json').read_text())[r['case']].replace('$','') if '-plain' in p.stem else json.loads((w/'prompts.json').read_text())[r['case']])
if __name__=='__main__':
    rows=[v for p in sorted(w.glob('candidate-*.jsonl')) if (v:=review(p))]
    (w/'review.json').write_text(json.dumps(rows,ensure_ascii=False,indent=1)+'\n')
    for v in rows:
        print(v['tag'],len(v['preload']),v['cli']['rule_read_pass'],[(s['previous']['result'],s['call'],s['result'],s['exact']) for s in v['reads']])
