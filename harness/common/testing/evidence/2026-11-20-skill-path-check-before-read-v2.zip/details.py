from pathlib import Path
import json,hashlib
from audit import audits,parse,w,canonical,negative
def texts(payload):
    raw=payload.get('output',[])
    return [raw] if isinstance(raw,str) else [i.get('text','') for i in raw if isinstance(i,dict)]
def unpack(s):
    try:a=json.loads(s)
    except ValueError:return s
    if isinstance(a,dict) and isinstance(a.get('output'),str):return a['output']
    return s
def load_detail(p):
    audit=audits(p)
    if audit is None:return
    raw,=list((w/(p.stem+'-profile')/'sessions').rglob('rollout-*.jsonl'))
    calls=[];ids={}
    for n,line in enumerate(raw.open(),1):
        d=json.loads(line)
        if d['type']!='response_item':continue
        e=d['payload'];kind=e.get('type')
        if kind in ('custom_tool_call','function_call'):
            record=dict(call=n,name=e['name'],source=e.get('input',e.get('arguments','')))
            calls.append(record);ids[e['call_id']]=record
        elif kind in ('custom_tool_call_output','function_call_output') and e['call_id'] in ids:
            ids[e['call_id']].update(result=n,outputs=[unpack(s) for s in texts(e)])
    body=(w/'candidate-common-normal'/canonical).read_text()
    case=audit['case']
    for c in calls:
        c['body_returned']=any(body in s for s in c.get('outputs',[]))
    focused=[{'call':c['call'],'result':c.get('result'),'source':c['source'],
              'body_returned':c['body_returned'],'outputs':['full owner SHA-256 '+audit['body_sha256'] if s==body else s[:650] for s in c.get('outputs',[])]}
             for c in calls if c['body_returned'] or any(x in c['source'] for x in ('/SKILL.md','/training/tool','lstat','namei'))]
    return dict(tag=p.stem,calls=calls,focus=focused,cli_audit=audit)
if __name__=='__main__':
    items=[d for p in sorted(w.glob('candidate-*.jsonl')) if (d:=load_detail(p))]
    (w/'detail-results.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    for d in items:
        print(d['tag'],[(c['call'],c.get('result'),c['body_returned'],c['source'].replace('\n',' ')[:135]) for c in d['focus']])
