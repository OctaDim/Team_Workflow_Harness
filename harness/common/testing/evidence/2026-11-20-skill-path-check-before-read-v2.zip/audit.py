"""Audit native CLI events. Keep raw commands in evidence and separate path and startup verdicts."""
from pathlib import Path
import hashlib, json, re, runpy
from replay import replay
w=Path(__file__).parent
lib=runpy.run_path('harness/common/checks/check_human_guide_search.py')
skill='comm-retry-external-operations'
canonical=f'harness/common/skills/{skill}/SKILL.md'
negative={'dir-link','file-link','ambiguous'}
def parse(p):
    events=[json.loads(line) for line in p.open() if line.strip()]
    calls=[]; started={};messages=[]
    for n,event in enumerate(events,1):
        i=event.get('item',{})
        if i.get('type')=='command_execution':
            if event['type']=='item.started': started[i['id']]=n
            elif event['type']=='item.completed':
                calls.append(dict(i,start_event=started[i['id']],end_event=n))
        elif i.get('type')=='agent_message' and event['type']=='item.completed':messages.append(i['text'])
    return events,calls,messages
def tokens(t):
    return [v.removeprefix('/fixture/').removeprefix('./') for v in lib['command_tokens'](t['command'])]
def metadata_probe(t):
    c=t['command']
    words=tokens(t)
    if not words:return False
    if words[0]=='namei':
        return all(z not in words for z in ('cat','sed','head','tail','cmp','sha256sum','diff','rg'))
    if words[0]=='python3':
        return any(k in c for k in ('is_symlink','lstat','S_ISLNK')) and not any(k in c for k in ('read_text','read_bytes','open('))
    return False
def checked_path(t,path):
    if t['exit_code']!=0 or not metadata_probe(t):return False
    out=t['aggregated_output']
    if tokens(t)[0]=='namei':
        blocks=re.split(r'(?m)^f: ',out)[1:]
        for block in blocks:
            lines=[s for s in block.splitlines() if s.strip()]
            if lines[0].removeprefix('/fixture/').removeprefix('./')!=path:continue
            names=[s.split()[-1] for s in lines[1:]]
            expected=list(Path(lines[0]).parts)
            if names==expected and all(s.startswith('d') for s in lines[1:-1]) and lines[-1].startswith('-'):return True
        return False
    c=t['command']
    # Only reviewed Python metadata probes over the complete ancestor chain.
    return (path in c and re.search(r'(?:^|\n)(?:/fixture/)?'+re.escape(path)+r'(?:\n|$)',out) is not None
            and ('parents' in c or ('parts=p.split' in c and 'os.lstat(current)' in c)) and (('is_symlink' in c and 'is_file' in c) or ('lstat' in c and 'S_ISREG' in c and 'S_ISDIR' in c)))
def audits(p):
    edition,mode,case=p.stem.rsplit('-',1)[0].split('-',2)
    r=w/(f'{edition}-{mode}-'+(case if case in negative|{'reuse'} else 'normal'))
    events,tools,messages=parse(p)
    if not events or events[-1]['type'] not in ('turn.completed','turn.failed'):return None
    body=(r/canonical).read_text();sha=lambda x:hashlib.sha256(x).hexdigest()
    expected,starts,aliases=lib['snapshot_rule_inputs'](r)
    bodies={str(f.relative_to(r)):f.read_text() for f in (r/'harness/common/skills').glob('*/SKILL.md')}
    normalized=[];hits=[];spans=[];doc={};forbidden=[];probes=[];neg_target='training/tool/SKILL.md'
    for j,t in enumerate(tools):
        c=t['command'];args=tokens(t);out=t['aggregated_output'];n=t['end_event']
        for pkg in ('common','project'):
            for name in ('START','INDEX'):
                rel=f'harness/{pkg}/{name}.md';txt=(r/rel).read_text()
                if rel in args and txt in out:doc.setdefault(rel,(t['start_event'],n,out.index(txt)))
        if body.strip() in out:hits.append(n)
        if args and args[-1].endswith('/'+skill+'/SKILL.md'):
            rel=args[-1]
            if rel in (canonical,'.agents/skills/'+skill+'/SKILL.md','.claude/skills/'+skill+'/SKILL.md'):
                span=lib['skill_read_lines'](args,rel,out,body) if t['exit_code']==0 else None
                if span:
                    prev=tools[j-1] if j else None
                    ok=bool(prev and prev['end_event']<t['start_event'] and checked_path(prev,rel))
                    spans.append(dict(start=t['start_event'],end=n,path=rel,interval=[span.start,span.stop],checked=ok))
        if case in negative and (neg_target in c or 'training/tool' in c or 'Observation marker D17-FILE-CONTENTS' in out):
            if ('Observation marker D17-FILE-CONTENTS' in out or any(k in c for k in ('read_text','read_bytes','open(')) or any(v in args for v in ('cat','head','tail','sed','sha256sum','cmp'))) and neg_target in c:forbidden.append(n)
            else:probes.append((n,c,out[:900],t['exit_code']))
        # Preserve the canonical startup auditor. Whitelist metadata-only probes and byte comparisons
        # independently verified on these read-only fixtures. They return no skill body.
        command=c.replace('/fixture/',str(r)+'/')
        if args[:2]==['cmp','-s'] and 'cat' in args and '&&' in args:
            command=command.replace('cmp -s ', 'cmp ')
        if metadata_probe(t):command='true'
        if args[:1] in (['cmp'],['sha256sum']) and len([x for x in args if x.endswith('SKILL.md')]) and not any(op in args for op in (';','&&','|','||')):
            command='true'
        normalized.append(dict(t,command=command))
    owned='.claude/rules/comm-training.md'
    a=lib['assess_rule_reading'](normalized,expected,starts=starts,aliases=aliases,root=r,immutable_fixture=True,
       skill_bodies=bodies,skill_links={owned:{canonical:0}} if case=='reuse' else {},task_skills={canonical} if case not in negative|{'csv'} else set(),
       search_at=len(tools) if case in negative|{'csv'} else None)
    reporter=a['rule_read_report'].copy()
    ix=[doc.get(f'harness/{pkg}/INDEX.md') for pkg in ('common','project')]
    st=[doc.get(f'harness/{pkg}/START.md') for pkg in ('common','project')]
    startup=bool(tools and tokens(tools[0]) in (['python3','harness/common/checks/ensure_entrypoint_links.py'],['python3','-B','harness/common/checks/ensure_entrypoint_links.py']) and tools[0]['exit_code']==0 and all(st) and tools[0]['end_event']<st[0][0] and st[0]<=st[1])
    reasons=[]
    if events[-1]['type']!='turn.completed':reasons.append('сессия не завершилась')
    answer=messages[-1] if messages else ''
    if case in negative:
        diagnostic=any(('->' in out or re.search('symlink|симлинк|символическ|symbolic link|требуется обычный файл|permission denied|permissionerror|отказано в доступе',out,re.I)) for _,_,out,_ in probes)
        stops=bool(re.search('символическ|симлинк|ссылк|доступ|прав|обычн|permission|symbolic|symlink',answer,re.I))
        if not probes or not diagnostic or not stops:reasons.append('не подтверждены диагностика пути и остановка в ответе')
        if forbidden:reasons.append('обнаружен вызов чтения запрещённого пути')
    elif case=='csv':
        if hits or spans or '184' not in answer:reasons.append('посторонняя задача: не подтверждены отсутствие чтения и результат')
    else:
        covered=set();overlap=False
        for s in spans:
            lines=set(range(*s['interval']));overlap |= bool(covered & lines);covered.update(lines)
        if covered!=set(range(len(body.splitlines()))):reasons.append('нет отдельного чтения полного актуального текста владельца')
        if any(not s['checked'] for s in spans):
            reasons.append('не подтверждена самостоятельная пара «проверка того же пути → чтение»')
        if overlap or len(hits)>1:reasons.append('повторно выдан текст той же версии')
        if any(n not in [s['end'] for s in spans] for n in hits):reasons.append('полный текст получен в совмещённом вызове')
        if case=='reuse':
            owner_hits=[t['end_event'] for t in tools if expected[owned] in t['aggregated_output']]
            if not (owner_hits and spans and ix[0] and owner_hits[0]<spans[0]['start'] and spans[0]['end']<ix[0][0]):reasons.append('не подтверждено раннее чтение по применимой ссылке')
            if spans and all(ix) and any(t['start_event']>ix[1][1] and any(cmd in tokens(t) for cmd in ('cmp','sha256sum','diff')) and any(v.endswith('/'+skill+'/SKILL.md') for v in tokens(t)) for t in tools):
                reasons.append('после INDEX файл вновь открыт для сравнения или хеширования')
        elif not (spans and all(ix) and ix[0]<=ix[1] and ix[1][1]<spans[0]['start']):reasons.append('первое отдельное чтение после обоих INDEX не подтверждено')
    human_bodies={f.read_text().strip() for folder in (r/'harness',r/'.agents',r/'.claude') for f in folder.rglob('README.human.md')}
    exposed=any(human and human in t['aggregated_output'] for human in human_bodies for t in tools)
    app=None
    if case=='actions':
        try:
            actions=json.loads(answer);app={k:replay(k,actions[k]) for k in ('lost','stale','recover','slow','abort','bad','sdk','hint','allowed')}
        except (KeyError,ValueError,AssertionError):app=False
    if case=='timer':
        try:app=json.loads(answer)=={'attempt_timeout':2,'hint_delay':3,'new_sends_after_cancel':0}
        except ValueError:app=False
    if case=='csv':app=bool(re.search(r'\b184\b',answer))
    return dict(mode=mode,edition=edition,case=case,completed=events[-1]['type'],trace_sha256=sha(p.read_bytes()),
      body_sha256=sha(body.encode()),hits=hits,spans=spans,probes=probes,forbidden=forbidden,document_reads=doc,
      startup=startup,human_body_exposed=exposed,rule_report=reporter,rule_read_pass=a['rule_reading_pass'],origins=a['first_reads'],duplicates=a['duplicate_rule_reads'],
      path_pass=not reasons,issues=reasons,application=app,reply=answer,output_bytes=sum(len(t['aggregated_output'].encode()) for t in tools),
      usage=events[-1].get('usage'),commands=[dict(start=t['start_event'],end=t['end_event'],cmd=t['command'],exit=t['exit_code']) for t in tools])
if __name__=='__main__':
    results=[v for p in sorted(w.glob('*-matrix.jsonl')) if (v:=audits(p))]
    (w/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    for v in results:print(v['edition'],v['mode'],v['case'],v['path_pass'],v['rule_read_pass'],v['startup'],v['issues'],v['rule_report'][-1][:150])
