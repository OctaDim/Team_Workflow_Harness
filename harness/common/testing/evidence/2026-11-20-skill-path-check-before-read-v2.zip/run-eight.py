from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
w=Path(__file__).parent
def run(case):
    mode,scenario,iteration=case
    return subprocess.run([sys.executable,str(w/'native-recorded.py'),'candidate',mode,scenario,iteration]).returncode
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,[(m,c,n) for n in ('one','two') for m in ('common','combined') for c in ('explicit','reuse')]))
sys.exit(int(any(results)))
