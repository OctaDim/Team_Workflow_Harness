from pathlib import Path
import json
import re

work = Path(__file__).parent
case_names = {'baseline': ('task', 'inbox'), 'skill-routing': ('task', 'inbox', 'read', 'unready', 'blocked')}
requests = ('2026-11-17-fixture-policy-region', '2026-11-18-fixture-policy-retention')
verified = {}
for edition, cases in case_names.items():
    for mode in ('common', 'both'):
        for case in cases:
            tag = f'{edition}-{mode}-{case}'
            s = json.loads((work / f'{tag}.summary.json').read_text())
            assert s['exit'] == 0 and s['complete'] and s['foreign_index_preserved'], tag
            commits = s['commits']
            end = s['answers'][-1]
            result = {'commits': commits, 'commit_titles_in_final': [c['subject'] in end for c in commits]}
            if case in ('task', 'inbox'):
                assert s['skill_reads']['owner'] and s['skill_reads']['ce_commit'], tag
                assert s['status'] == 'M  foreign.txt\n', tag
                assert all(c['revision'][:7] in end for c in commits), tag
            if case == 'task':
                assert len(commits) == 1 and commits[0]['files'] == ['limits.py', 'policy.md'], tag
                assert s['exact_limits'] == 'LIMIT = 5\n' and 'limit is 5' in s['policy'], tag
            elif case == 'inbox':
                assert len(commits) == 2 and list(s['inbox_statuses'].values()) == ['completed'] * 2, tag
                for commit, name in zip(commits, requests, strict=True):
                    assert commit['files'] == [f'harness/common/decisions/{name}.md', f'harness/common/inbox/{name}/request.md'], tag
                first = next(i for i, command in enumerate(s['commands'])
                             if re.search(r"""['"\s]commit['"\s]""", command) and '-F' in command)
                second = next(i for i, command in enumerate(s['commands'])
                              if 'retention' in command and any(op in command for op in ('write_text(', 'write_bytes(')))
                assert first < second, (tag, first, second)
                result['first_commit_command_index'] = first
                result['next_request_first_mutation_command_index'] = second
            else:
                assert not commits, tag
                if case == 'read':
                    assert s['status'] == 'M  foreign.txt\n' and end.strip() == '3', tag
                    assert not s['skill_reads']['owner'] and not s['skill_reads']['ce_commit'], tag
                elif case == 'unready':
                    assert s['status'] == 'M  foreign.txt\n?? draft.md\n', tag
                else:
                    assert s['status'] == 'M  foreign.txt\n M limits.py\n M policy.md\n', tag
                    assert s['exact_limits'] == 'LIMIT = 5\n' and 'limit is 5' in s['policy'], tag
                    assert '.git/index.lock' in end and 'только для чтения' in end, tag
            verified[tag] = result
print('Validated cases:', len(verified))
(work / 'scenario-audit.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
