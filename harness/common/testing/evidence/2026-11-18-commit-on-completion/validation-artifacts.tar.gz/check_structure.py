from hashlib import sha256
import json
from pathlib import Path
import re
from select import select
import subprocess
import tempfile

run = Path(__file__).parent
binary_home = Path('/home/octadim/.codex/packages')
binary = binary_home / 'standalone/current/bin/codex'
candidate = Path.cwd() / 'harness/common/inbox/2026-11-18-commit-on-completion/candidate-skill-routing'
skill_names = ('comm-commit-task-stages', 'comm-process-harness-inbox', 'comm-select-development-workflow')
py = '/tmp/harness-full-routes.sX93GCkU/venv/bin/python'

def file_manifest(folder):
    files = sorted(path for path in folder.rglob('*') if path.is_file())
    assert not any(path.is_symlink() for path in folder.rglob('*'))
    return {path.relative_to(folder).as_posix(): sha256(path.read_bytes()).hexdigest() for path in files}

def run_check(path, command):
    result = subprocess.run(command, cwd=path, check=True, text=True, capture_output=True, timeout=90)
    return {'command': command, 'exit': result.returncode, 'stdout': result.stdout}

def catalogue(path, runtime, expected):
    command = ['/usr/bin/bwrap', '--die-with-parent', '--unshare-pid', '--ro-bind', '/', '/',
               '--dev-bind', '/dev', '/dev', '--proc', '/proc',
               '--tmpfs', '/home/octadim', '--tmpfs', '/tmp', '--ro-bind', str(path), str(path),
               '--bind', str(runtime), '/home/octadim/.codex', '--ro-bind', str(binary_home), str(binary_home),
               '--chdir', str(path), '--', str(binary), 'app-server', '--listen', 'stdio://']
    messages = [
        {'id': 1, 'method': 'initialize', 'params': {'clientInfo': {'name': 'fixture-commit-catalogue', 'version': '1'}}},
        {'method': 'initialized'},
        {'id': 2, 'method': 'skills/list', 'params': {'cwds': [str(path)], 'forceReload': True}},
    ]
    with subprocess.Popen(command, cwd=path, text=True, stdin=subprocess.PIPE,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE) as process:
        try:
            for message in messages:
                process.stdin.write(json.dumps(message) + '\n')
                process.stdin.flush()
                if 'id' not in message:
                    continue
                for _ in range(40):
                    if not select([process.stdout], [], [], 15)[0]:
                        raise TimeoutError(f'No reply to {message["method"]}')
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError(f'Closed catalogue stderr: {process.stderr.read()}')
                    reply = json.loads(line)
                    if reply.get('id') == message['id']:
                        break
                else:
                    raise RuntimeError(f'No matched reply to {message["method"]}')
        finally:
            process.stdin.close()
            process.stdin = None
            process.communicate(timeout=20)
    assert process.returncode == 0 and reply.get('id') == 2 and 'result' in reply
    skills = [skill for item in reply['result']['data'] for skill in item.get('skills', [])]
    selected = {name: [skill for skill in skills if skill['name'] == name] for name in expected}
    for name, owners in selected.items():
        assert len(owners) == 1 and owners[0]['path'] == str(path / '.agents/skills' / name / 'SKILL.md'), selected
        assert owners[0].get('enabled') is not False
    return selected

def sizes(root):
    paths = [root / 'AGENTS.md', root / 'CLAUDE.md']
    paths += [root / 'harness' / pkg / file for pkg in ('common', 'project') for file in ('START.md', 'INDEX.md')]
    paths += [path for path in (root / '.claude/rules').rglob('*.md') if path.name != 'README.human.md']
    metadata = []
    for path in (root / '.agents/skills').glob('*/SKILL.md'):
        fields = re.findall(r'(?m)^(?:name|description):.*$', path.read_text().split('---', 2)[1])
        metadata.append('\n'.join(fields).encode())
    return {'startup_files': len(paths), 'startup_bytes': sum(path.stat().st_size for path in paths),
            'skill_metadata_files': len(metadata), 'skill_metadata_bytes': sum(map(len, metadata))}

data = {}
for mode in ('common', 'both'):
    base = run / f'case-baseline-{mode}-inbox'
    case = run / f'case-skill-routing-{mode}-inbox'
    for name in skill_names:
        files = file_manifest(candidate / name)
        for location in ('harness/common/skills', '.agents/skills', '.claude/skills'):
            assert file_manifest(case / location / name) == files
    project = case / 'harness/project'
    assert (project / 'base/fixture.md').is_file() == (mode == 'both')
    assert (project / 'testing/evidence/harness').is_dir() or mode == 'both'
    project_before = file_manifest(project)
    startup = ['python3', '-B', 'harness/common/checks/ensure_entrypoint_links.py']
    checks = [run_check(case, startup), run_check(case, startup)]
    assert file_manifest(project) == project_before
    checks.append(run_check(case, [py, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                                  'harness/common/testing/tests/test_rule_copies.py',
                                  'harness/common/testing/tests/test_skills_first_knowledge.py']))
    with tempfile.TemporaryDirectory(dir=run) as runtime:
        selected = catalogue(case, Path(runtime), (*skill_names, 'ce-commit'))
    data[mode] = {'checks': checks, 'catalogue': selected, 'project_unchanged': True,
                  'base_startup': sizes(base), 'candidate_startup': sizes(case)}
    print(mode, checks[-1]['stdout'].strip().splitlines()[-1], 'four native names listed', flush=True)
(run / 'structural.json').write_text(json.dumps(data, indent=2) + '\n')
