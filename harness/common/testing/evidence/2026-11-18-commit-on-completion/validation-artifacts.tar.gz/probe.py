from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path.cwd()
RUN = Path(__file__).parent
ACCOUNT = Path('/home/octadim')
CODEX = ACCOUNT / '.codex/packages/standalone/current/bin/codex'
CE_COMMIT = ACCOUNT / '.codex/plugins/cache/compound-engineering-plugin/compound-engineering/3.38.0/skills/ce-commit/SKILL.md'
PROMPTS = {
    'task': 'Маршрут — простое выполнение. Исправь лимит в limits.py с 3 на 5 и обнови пояснение в policy.md. Выполни smoke.py и заверши задачу.',
    'inbox': 'Выполни две открытые заявки INBOX в порядке создания. Разрешены их выполнение, описанные в них проверки и публикация указанных результатов в синтетическом проекте. Заверши обе заявки.',
    'read': 'Маршрут — простое выполнение. Прочитай limits.py и policy.md и назови лимит. Нужен только ответ.',
    'unready': 'Маршрут — простое выполнение. Создай draft.md с вопросом, следует ли повысить лимит с 3 до 5. Это незавершённый черновик для следующего обсуждения. Остановись после записи.',
    'blocked': 'Маршрут — простое выполнение. Исправь лимит в limits.py с 3 на 5 и обнови пояснение в policy.md. Выполни smoke.py и заверши задачу.',
}
OWNER = 'comm-commit-task-stages'
SYNTHETIC_REQUESTS = tuple(
    (f'2026-11-1{day}-fixture-policy-{topic}', topic, value)
    for day, topic, value in ((7, 'region', 'north'), (8, 'retention', 'seven days'))
)

def git(folder, *args):
    return subprocess.run(['git', *args], cwd=folder, check=True, text=True, capture_output=True).stdout

def write(folder, relative, body):
    target = folder / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(body, encoding='utf-8')

def prepare(tag, edition, mode, scenario):
    folder = RUN / f'case-{tag}'
    folder.mkdir()
    excluded = shutil.ignore_patterns('inbox', 'evidence', 'handoffs', '__pycache__', '.pytest_cache')
    shutil.copytree(ROOT / 'harness/common', folder / 'harness/common', ignore=excluded)
    if mode == 'both':
        shutil.copytree(ROOT / 'harness/project', folder / 'harness/project', ignore=excluded)
        write(folder, 'harness/project/base/fixture.md', 'Synthetic existing project.\n')
    for name in ('AGENTS.md', 'CLAUDE.md'):
        shutil.copyfile(ROOT / name, folder / name)
    if edition != 'baseline':
        overlay = RUN / edition
        assert overlay.is_dir()
        for source in overlay.rglob('*.md'):
            shutil.copyfile(source, folder / source.relative_to(overlay)) if (folder / source.relative_to(overlay)).exists() else write(folder, source.relative_to(overlay), source.read_text())
    shutil.copytree(folder / 'harness/common/rules', folder / '.claude/rules')
    for native in ('.agents', '.claude'):
        shutil.copytree(folder / 'harness/common/skills', folder / native / 'skills')
    write(folder, '.agents/skills/ce-commit/SKILL.md', CE_COMMIT.read_text())
    startup = subprocess.run(['python3', '-B', 'harness/common/checks/ensure_entrypoint_links.py'],
                             cwd=folder, check=True, text=True, capture_output=True)
    assert 'Entrypoint check completed' in startup.stdout
    write(folder, 'limits.py', 'LIMIT = 3\n')
    write(folder, 'policy.md', '# Dispatch policy\n\nThe default limit is 3.\n')
    write(folder, 'smoke.py', "from pathlib import Path\nfrom limits import LIMIT\n\nassert LIMIT == 5\nassert 'limit is 5' in Path('policy.md').read_text()\n")
    write(folder, 'foreign.txt', 'Original foreign content.\n')
    if scenario == 'inbox':
        for name, topic, value in SYNTHETIC_REQUESTS:
            prefix = f'harness/common/inbox/{name}'
            result = f'harness/common/decisions/{name}.md'
            canonical = f'# Fixture {topic}\n\nValue: {value}.'
            write(folder, f'{prefix}/README.human.md', '# Sample request\n\nExample: save a policy decision.\n')
            write(folder, f'{prefix}/request.md', f'''# Save fixture policy for {topic}

Created: {name[:10]}T09:00:00+03:00.

Publish a permanent ordinary decision in `{result}`, using exactly these three
lines and a final newline:

```markdown
{canonical}
```

Verify the exact saved contents and path. This is the sole file result.
Record successful publication in this request and close it. These are
independent decisions. Proceed to the other request at the normal point.

## Execution

Status: new
Result: not executed
Reason: Synthetic common inbox fixture.
Updated: {name[:10]}
''')
    git(folder, 'init', '-b', 'octadim/fixture')
    git(folder, 'config', 'user.name', 'Harness Fixture')
    git(folder, 'config', 'user.email', 'fixture@example.invalid')
    git(folder, 'config', 'commit.gpgsign', 'false')
    git(folder, 'config', 'core.hooksPath', '/dev/null')
    git(folder, 'add', '--', '.')
    git(folder, 'commit', '-m', 'test: initialize synthetic fixture')
    write(folder, 'foreign.txt', 'Foreign staged content must survive.\n')
    git(folder, 'add', '--', 'foreign.txt')
    return folder

def native(edition, mode, scenario):
    tag = f'{edition}-{mode}-{scenario}'
    fixture = prepare(tag, edition, mode, scenario)
    seed = git(fixture, 'rev-parse', 'HEAD').strip()
    foreign_index = git(fixture, 'ls-files', '--stage', '--', 'foreign.txt')
    runtime = RUN / f'runtime-{tag}'
    runtime.mkdir()
    command = [
        '/usr/bin/bwrap', '--die-with-parent', '--unshare-pid', '--ro-bind', '/', '/',
        '--dev-bind', '/dev', '/dev', '--proc', '/proc',
        '--tmpfs', str(ACCOUNT), '--tmpfs', '/tmp',
        '--bind', str(fixture), str(fixture),
        '--bind', str(runtime), str(ACCOUNT / '.codex'),
        '--ro-bind', str(ACCOUNT / '.codex/packages'), str(ACCOUNT / '.codex/packages'),
        '--ro-bind-try', str(ACCOUNT / '.codex/auth.json'), str(ACCOUNT / '.codex/auth.json'),
    ]
    if scenario == 'blocked':
        command.extend(['--ro-bind', str(fixture / '.git'), str(fixture / '.git')])
    command.extend([
        '--chdir', str(fixture), '--', str(CODEX), '-a', 'never',
        'exec', '--ignore-user-config', '--ephemeral', '-s', 'danger-full-access', '--json', '-',
    ])
    prompt = PROMPTS[scenario] + '\nРаботай только в этом одноразовом синтетическом проекте, через локальные команды без сетевых инструментов и без делегирования.\n'
    log = RUN / f'{tag}.jsonl'
    with log.open('x', encoding='utf-8') as out, (RUN / f'{tag}.stderr').open('x', encoding='utf-8') as err:
        try:
            result = subprocess.run(command, cwd=fixture, input=prompt, stdout=out, stderr=err, text=True, timeout=210)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
    items = [event['item'] for event in events if event.get('type') == 'item.completed']
    commands = [item for item in items if item.get('type') == 'command_execution']
    answers = [item['text'] for item in items if item.get('type') == 'agent_message']
    commits = []
    for revision in git(fixture, 'rev-list', '--reverse', f'{seed}..HEAD').splitlines():
        commits.append({
            'revision': revision,
            'subject': git(fixture, 'show', '-s', '--format=%s', revision).strip(),
            'files': git(fixture, 'diff-tree', '--no-commit-id', '--name-only', '-r', revision).splitlines(),
        })
    observed = {}
    for label, path in {
            'owner': fixture / 'harness/common/skills' / OWNER / 'SKILL.md',
            'ce_commit': fixture / '.agents/skills/ce-commit/SKILL.md',
            'workflow': fixture / 'harness/common/skills/comm-process-harness-inbox/SKILL.md'}.items():
        observed[label] = [index for index, cmd in enumerate(commands)
                           if path.read_text().strip() in cmd.get('aggregated_output', '')]
    completion = next((event for event in events if event.get('type') == 'turn.completed'), None)
    report = {
        'edition': edition, 'mode': mode, 'scenario': scenario, 'exit': code,
        'complete': completion is not None, 'usage': completion.get('usage') if completion else None,
        'skill_reads': observed, 'commits': commits, 'answers': answers,
        'commands': [cmd['command'] for cmd in commands],
        'foreign_index_preserved': foreign_index == git(fixture, 'ls-files', '--stage', '--', 'foreign.txt'),
        'status': git(fixture, 'status', '--short'),
        'exact_limits': (fixture / 'limits.py').read_text(),
        'policy': (fixture / 'policy.md').read_text(),
        'inbox_statuses': {
            name: (fixture / 'harness/common/inbox' / name / 'request.md').read_text().split('Status:')[-1].splitlines()[0].strip()
            for name, _, _ in SYNTHETIC_REQUESTS
        } if scenario == 'inbox' else {},
    }
    (RUN / f'{tag}.summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(tag, code, report['complete'], [c['files'] for c in commits], observed, flush=True)

edition = sys.argv[1]
scenarios = sys.argv[2:]
with ThreadPoolExecutor(max_workers=4) as executor:
    list(executor.map(lambda test: native(edition, *test),
                      [(mode, scenario) for scenario in scenarios for mode in ('common', 'both')]))
