from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory

run = Path(__file__).parent
name = 'comm-task-commit-on-completion.md'
candidate = Path.cwd() / 'harness/common/inbox/2026-11-18-commit-on-completion/candidate-rule-v1' / name
py = '/tmp/harness-full-routes.sX93GCkU/venv/bin/python'
startup = ['python3', '-B', 'harness/common/checks/ensure_entrypoint_links.py']
expected = 'a15e372a37b16c7c440eaed5fcffae55e8b898155137d76fc836b65834893477'
assert sha256(candidate.read_bytes()).hexdigest() == expected

def manifest(folder):
    entries = sorted(folder.rglob('*'))
    assert not any(path.is_symlink() for path in entries)
    return {path.relative_to(folder).as_posix(): sha256(path.read_bytes()).hexdigest()
            for path in entries if path.is_file()}

def digest(root, names):
    return {name: sha256((root / name).read_bytes()).hexdigest() for name in names}

def execute(folder, command, expected_exit=0):
    result = subprocess.run(command, cwd=folder, text=True, capture_output=True, timeout=90)
    assert result.returncode == expected_exit, (command, result.returncode, result.stdout, result.stderr)
    return {'command': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

summary = {}
with TemporaryDirectory(prefix='harness-rule-structure.') as tmp:
    for mode in ('common', 'both'):
        fixture = Path(tmp) / mode
        source = run / f'case-always-rule-{mode}-task'
        assert not any(path.is_symlink() for path in source.rglob('*'))
        shutil.copytree(source, fixture, ignore=shutil.ignore_patterns('.git', '__pycache__', '.pytest_cache'))
        project = fixture / 'harness/project'
        assert (project / 'base/fixture.md').is_file() == (mode == 'both')
        assert (project / 'testing/evidence/harness').is_dir() or mode == 'both'
        before_project = manifest(project)
        paths = ['AGENTS.md', 'CLAUDE.md', f'harness/common/rules/{name}', f'.claude/rules/{name}']
        before = digest(fixture, paths)
        assert before[paths[2]] == before[paths[3]] == expected
        checks = [execute(fixture, startup), execute(fixture, startup)]
        assert digest(fixture, paths) == before and manifest(project) == before_project
        checks.append(execute(fixture, [py, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                                        'harness/common/testing/tests/test_rule_copies.py',
                                        'harness/common/testing/tests/test_skills_first_knowledge.py']))
        (fixture / paths[3]).unlink()
        missing_rule = execute(fixture, startup, expected_exit=2)
        assert name in missing_rule['stdout'] + missing_rule['stderr']
        assert digest(fixture, paths[:3]) == {path: before[path] for path in paths[:3]}
        assert not (fixture / paths[3]).exists() and manifest(project) == before_project
        summary[mode] = {'rule_sha256': expected, 'checks': checks, 'missing_copy': missing_rule,
                         'project_unchanged': True, 'entrypoints_unchanged': True}
        print(mode, checks[-1]['stdout'].strip().splitlines()[-1], 'missing copy refused')
(run / 'rule-structure.json').write_text(json.dumps(summary, indent=2) + '\n')
