from hashlib import sha256
from pathlib import Path
import json
import re
import sys

run = Path(__file__).parent
expected_rule = 'a15e372a37b16c7c440eaed5fcffae55e8b898155137d76fc836b65834893477'
relative_rule = Path('harness/common/rules/comm-task-commit-on-completion.md')
requests = ('2026-11-17-fixture-policy-region', '2026-11-18-fixture-policy-retention')
editions = {
    'always-rule': ('task', 'inbox', 'read', 'unready', 'blocked', 'missing', 'ambiguous'),
    'always-rule-temp': ('task', 'inbox'),
}
verified = {}
for edition in sys.argv[1:]:
    for mode in ('common', 'both'):
        for case in editions[edition]:
            tag = f'{edition}-{mode}-{case}'
            fixture = run / f'case-{tag}'
            rule_paths = [fixture / relative_rule, fixture / '.claude/rules' / relative_rule.name]
            assert all(sha256(path.read_bytes()).hexdigest() == expected_rule for path in rule_paths), tag
            s = json.loads((run / f'{tag}.summary.json').read_text())
            assert s['exit'] == 0 and s['complete'] and s['foreign_index_preserved'], tag
            assert s['skill_reads']['rule'], tag
            commits = s['commits']
            end = s['answers'][-1]
            result = {'commits': commits, 'input_tokens': s['usage']['input_tokens']}
            if case in ('task', 'inbox'):
                assert s['skill_reads']['owner'] and s['skill_reads']['ce_commit'], tag
                assert s['status'] == 'M  foreign.txt\n', tag
                assert all(c['revision'][:7] in end and c['subject'] in end for c in commits), tag
                commit_steps = [(i, cmd) for i, cmd in enumerate(s['commands'])
                                if re.search(r"""['"\s]commit['"\s]""", cmd) and '-F' in cmd]
                assert commit_steps, tag
                result['first_commit_step'] = commit_steps[0][0]
                result['commits_used_git_metadata_file'] = [
                    i for i, cmd in commit_steps if re.search(r"-F (?:['\"])?\.git/", cmd)]
                result['commit_used_standard_input'] = [i for i, cmd in commit_steps if re.search(r"-F -\s", cmd)]
            if case == 'task':
                assert len(commits) == 1 and commits[0]['files'] == ['limits.py','policy.md'], tag
                assert s['exact_limits'] == 'LIMIT = 5\n' and 'limit is 5' in s['policy'], tag
            elif case == 'inbox':
                assert len(commits) == 2 and list(s['inbox_statuses'].values()) == ['completed'] * 2, tag
                for commit, name in zip(commits, requests, strict=True):
                    assert commit['files'] == [f'harness/common/decisions/{name}.md', f'harness/common/inbox/{name}/request.md'], tag
                mutation = next(i for i, cmd in enumerate(s['commands'])
                                if 'retention' in cmd and any(op in cmd for op in ('write_text(', 'write_bytes(', 'apply_patch', 'cat >', 'mkdir ')))
                assert result['first_commit_step'] < mutation, (tag, result['first_commit_step'], mutation)
                result['next_inbox_write_step'] = mutation
            else:
                assert not commits, tag
                if case == 'read':
                    assert s['status'] == 'M  foreign.txt\n' and end.strip() == '3', tag
                    assert not s['skill_reads']['owner'] and not s['skill_reads']['ce_commit'], tag
                elif case == 'unready':
                    assert s['status'] == 'M  foreign.txt\n?? draft.md\n', tag
                    assert 'черновик' in end.lower() and 'без коммита' in end.lower(), tag
                else:
                    assert s['status'] == 'M  foreign.txt\n M limits.py\n M policy.md\n', tag
                    assert s['exact_limits'] == 'LIMIT = 5\n' and 'limit is 5' in s['policy'], tag
                    if case == 'blocked':
                        assert '.git/index.lock' in end and 'только для чтения' in end, tag
                    elif case == 'missing':
                        assert 'comm-commit-task-stages' in end and 'отсутств' in end, tag
                    else:
                        assert 'comm-commit-task-stages' in end and 'две' in end, tag
            verified[tag] = result
print('Verified:', len(verified))
out = run / ('rule-scenario-audit.json' if len(sys.argv) > 2 else f'{sys.argv[1]}-audit.json')
out.write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
